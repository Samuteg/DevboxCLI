const express = require('express');
const routes = require('./src/routes'); // Agora a pasta src/routes existirá com certeza!
const app = express();
// ...