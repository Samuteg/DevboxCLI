# ✍️ Notes CRUD API v2.0.0 — Java (Spring Boot)

API RESTful de notas com autenticação JWT, refresh token, tags, paginação, busca textual e documentação Swagger — em **Java** com **Spring Boot 3**.

Este projeto é a versão Java dos templates [TypeScript](../ts/), [JavaScript](../js/) e [Ruby](../ruby/), mantendo as mesmas funcionalidades, estrutura e padrões de código.

## 📋 Índice

- [Funcionalidades](#-funcionalidades)
- [Tecnologias](#-tecnologias)
- [Pré-requisitos](#-pré-requisitos)
- [Instalação e execução](#-instalação-e-execução)
- [Variáveis de ambiente](#-variáveis-de-ambiente)
- [Scripts disponíveis](#-scripts-disponíveis)
- [Documentação Swagger](#-documentação-swagger)
- [Estrutura do projeto](#-estrutura-do-projeto)
- [Endpoints](#-endpoints)
  - [Autenticação](#-autenticação)
  - [Notas](#-notas)
- [Fluxo de uso](#-fluxo-de-uso)
- [Docker](#-docker)
- [Testes](#-testes)
- [Licença](#-licença)

## ✨ Funcionalidades

- ✅ Cadastro e autenticação de usuários (JWT + BCrypt)
- ✅ Refresh token com rotação (SHA-256)
- ✅ CRUD completo de notas
- ✅ Tags nas notas (array de strings)
- ✅ Paginação (page/limit)
- ✅ Busca textual no título e conteúdo
- ✅ Filtro por tag
- ✅ Rate limiting (100 req/min por IP)
- ✅ Documentação Swagger UI em `/docs`
- ✅ CORS habilitado
- ✅ Logs estruturados (SLF4J + Logback)
- ✅ Testes automatizados (JUnit 5 + MockMvc)
- ✅ Docker prontinho (multi-stage build)

## 🛠 Tecnologias

| Tecnologia       | Versão  | Descrição                          |
| ---------------- | ------- | ---------------------------------- |
| **Java**         | 17+     | Linguagem                          |
| **Spring Boot**  | 3.4.x   | Framework web                      |
| **SQLite**       | 3.x     | Banco de dados (via JDBC)          |
| **JWT (jjwt)**   | 0.12.x  | Tokens JWT                         |
| **BCrypt**       | —       | Hash de senhas (Spring Security)   |
| **Jakarta Validation** | —  | Validação de beans                 |
| **springdoc**    | 2.8.x   | OpenAPI / Swagger UI               |
| **JUnit 5**      | 5.x     | Testes                             |
| **MockMvc**      | —       | Testes HTTP                        |
| **Maven**        | 3.9+    | Build e dependências               |

**Comparativo com as demais versões:**

| Funcionalidade      | TypeScript / JS     | Ruby                | Java                          |
| ------------------- | ------------------- | ------------------- | ----------------------------- |
| Framework           | Fastify             | Sinatra             | **Spring Boot 3**            |
| Banco               | sql.js (WASM)       | sqlite3 (gem)       | **SQLite + JdbcTemplate**    |
| Validação           | Zod                 | Manual              | **Jakarta Validation**       |
| Logger              | Pino                | Logger (stdlib)     | **SLF4J + Logback**          |
| Testes              | Vitest              | Minitest            | **JUnit 5 + MockMvc**        |
| UUID                | uuid (lib)          | SecureRandom        | **UUID (java.util)**         |
| Autenticação        | @fastify/jwt        | jwt gem             | **jjwt + Spring Security**   |
| Swagger             | @fastify/swagger    | openapi.json        | **springdoc (auto)**         |

## 📋 Pré-requisitos

- Java 17+ (JDK)
- Maven 3.9+ (ou use o Maven Wrapper)
- SQLite3 (biblioteca C, já presente na maioria dos sistemas)

## 🚀 Instalação e execução

```bash
# 1. Clone o repositório e entre na pasta
cd templates/java

# 2. Compile e execute com Maven
./mvnw spring-boot:run

# OU: build o JAR e execute
./mvnw package -DskipTests
java -jar target/notes-crud-*.jar
```

O servidor iniciará em `http://localhost:3000`.

## 🔐 Variáveis de Ambiente

| Variável                      | Padrão            | Descrição                               |
| ----------------------------- | ----------------- | --------------------------------------- |
| `PORT`                        | `3000`            | Porta do servidor                       |
| `JWT_SECRET`                  | `fallback-secret` | Segredo para assinar os tokens JWT      |
| `JWT_EXPIRES_IN`              | `7d`              | Tempo de expiração do access token      |
| `REFRESH_TOKEN_EXPIRES_IN_DAYS` | `30`            | Dias de validade do refresh token       |
| `SPRING_PROFILES_ACTIVE`      | —                 | Perfil ativo do Spring                  |
| `LOG_LEVEL`                   | `DEBUG`           | Nível de log (`DEBUG`, `INFO`, `WARN`)  |

> 💡 As variáveis são mapeadas no `application.yml` com valores padrão.

## 📜 Scripts disponíveis

```bash
# Executar o servidor (modo dev)
./mvnw spring-boot:run

# Executar testes
./mvnw test

# Executar teste específico
./mvnw test -Dtest=AuthControllerTest
./mvnw test -Dtest=NoteControllerTest

# Build do JAR
./mvnw package -DskipTests

# Gerar Wrapper do Maven (se não existir)
mvn -N wrapper:wrapper
```

## 📖 Documentação Swagger

Acesse `http://localhost:3000/docs` para visualizar a documentação interativa da API via Swagger UI (springdoc).

A especificação OpenAPI também está disponível em `http://localhost:3000/v3/api-docs`.

## 📁 Estrutura do projeto

```
java/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── notescrud/
│   │   │           ├── NotesCrudApplication.java   # Ponto de entrada
│   │   │           ├── config/
│   │   │           │   ├── WebConfig.java          # CORS + interceptors
│   │   │           │   ├── RateLimitInterceptor.java # Rate limiting
│   │   │           │   └── OpenApiConfig.java      # Swagger / OpenAPI
│   │   │           ├── controller/
│   │   │           │   ├── AuthController.java     # Autenticação
│   │   │           │   ├── NoteController.java     # CRUD de notas
│   │   │           │   ├── SystemController.java   # Health + Swagger redirect
│   │   │           │   └── GlobalExceptionHandler.java
│   │   │           ├── repository/
│   │   │           │   └── DbRepository.java       # SQLite + JdbcTemplate
│   │   │           ├── security/
│   │   │           │   ├── JwtProvider.java        # Geração/validação JWT
│   │   │           │   ├── JwtAuthFilter.java      # Filtro de autenticação
│   │   │           │   └── SecurityConfig.java     # Spring Security
│   │   │           └── dto/
│   │   │               ├── AuthRequest.java        # Register/Login/Refresh
│   │   │               ├── NoteRequest.java        # Create/Update
│   │   │               ├── AuthResponse.java
│   │   │               ├── UserResponse.java
│   │   │               ├── NoteResponse.java
│   │   │               ├── NoteListResponse.java
│   │   │               └── ErrorResponse.java
│   │   └── resources/
│   │       └── application.yml                     # Configuração
│   └── test/
│       └── java/
│           └── com/
│               └── notescrud/
│                   ├── AuthControllerTest.java     # Testes de autenticação
│                   └── NoteControllerTest.java     # Testes de notas
├── pom.xml                    # Build Maven
├── Dockerfile                 # Imagem Docker
├── docker-compose.yml         # Docker Compose
└── README.md
```

## 📡 Endpoints

### 🔑 Autenticação

#### `POST /api/auth/register`

Cadastrar um novo usuário.

**Request:**
```json
{ "name": "João Silva", "email": "joao@email.com", "password": "123456" }
```

**Response 201:**
```json
{ "id": "uuid", "name": "João Silva", "email": "joao@email.com" }
```

**Erros:** `400` (validação), `409` (e-mail duplicado)

---

#### `POST /api/auth/login`

Autenticar e obter access token + refresh token.

**Request:**
```json
{ "email": "joao@email.com", "password": "123456" }
```

**Response 200:**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
  "refreshToken": "uuid",
  "user": { "id": "uuid", "name": "João Silva", "email": "joao@email.com" }
}
```

**Erros:** `400` (validação), `401` (credenciais inválidas)

---

#### `POST /api/auth/refresh`

Renovar access token usando refresh token.

**Request:**
```json
{ "refreshToken": "uuid" }
```

**Response 200:**
```json
{ "accessToken": "eyJ...", "refreshToken": "novo-uuid" }
```

> ⚠️ O refresh token é **rotacionado** a cada uso.

---

#### `POST /api/auth/logout`

Revogar todos os refresh tokens do usuário.

**Headers:** `Authorization: Bearer <accessToken>`

**Response 200:**
```json
{ "message": "Logout realizado com sucesso." }
```

---

#### `GET /api/auth/me`

Retorna os dados do usuário autenticado.

**Headers:** `Authorization: Bearer <accessToken>`

**Response 200:**
```json
{ "id": "uuid", "name": "João Silva", "email": "joao@email.com" }
```

---

### 📝 Notas

Todas as rotas de notas exigem `Authorization: Bearer <accessToken>`.

#### `POST /api/notes`

Criar uma nova nota.

**Request:**
```json
{ "title": "Minha nota", "content": "Conteúdo interessante", "tags": ["estudo", "java"] }
```

**Response 201:**
```json
{
  "id": "uuid",
  "title": "Minha nota",
  "content": "Conteúdo interessante",
  "tags": ["estudo", "java"],
  "createdAt": "2025-01-01T00:00:00Z",
  "updatedAt": "2025-01-01T00:00:00Z"
}
```

---

#### `GET /api/notes`

Listar notas com paginação, busca textual e filtro por tag.

**Query params:** `page` (1), `limit` (10), `search`, `tag`

**Response 200:**
```json
{
  "data": [{ ... }],
  "pagination": { "page": 1, "limit": 10, "total": 1, "totalPages": 1 }
}
```

---

#### `GET /api/notes/:id` / `PUT /api/notes/:id` / `DELETE /api/notes/:id`

Obter, atualizar e remover notas seguindo o mesmo padrão das demais versões.

## 🔄 Fluxo de uso

```mermaid
sequenceDiagram
    participant C as Cliente
    participant API

    C->>API: POST /api/auth/register
    API-->>C: 201 { id, name, email }

    C->>API: POST /api/auth/login
    API-->>C: 200 { accessToken, refreshToken, user }

    C->>API: POST /api/notes (Bearer accessToken)
    API-->>C: 201 { id, title, content, tags, ... }

    C->>API: GET /api/notes (Bearer accessToken)
    API-->>C: 200 { data[], pagination }

    C->>API: GET /api/notes/:id (Bearer accessToken)
    API-->>C: 200 { id, title, content, ... }

    C->>API: PUT /api/notes/:id (Bearer accessToken)
    API-->>C: 200 { id, title, content, ... }

    C->>API: DELETE /api/notes/:id (Bearer accessToken)
    API-->>C: 204

    Note over C,API: Access token expirou

    C->>API: POST /api/auth/refresh { refreshToken }
    API-->>C: 200 { accessToken, refreshToken }

    C->>API: POST /api/auth/logout (Bearer accessToken)
    API-->>C: 200 { message }
```

## 🐳 Docker

### Pré-requisitos

- Docker e Docker Compose instalados

### Build e execução

```bash
# Build da imagem
docker compose build

# Executar o container
docker compose up -d

# Ver logs
docker compose logs -f

# Parar
docker compose down
```

O build usa **multi-stage** com Maven para compilar e JRE para executar,
resultando em uma imagem enxuta (~150 MB).

## 🧪 Testes

Os testes utilizam **JUnit 5** + **MockMvc** para realizar requisições HTTP
simuladas sem a necessidade de um servidor rodando.

### Executar

```bash
# Todos os testes
./mvnw test

# Teste específico
./mvnw test -Dtest=AuthControllerTest
./mvnw test -Dtest=NoteControllerTest
```

Testes implementados:

- **Autenticação (11 testes):**
  - Registro com sucesso, e-mail duplicado, dados inválidos
  - Login com sucesso, credenciais inválidas
  - Dados do usuário (me), sem token
  - Refresh token, token inválido
  - Logout, refresh após logout

- **Notas (12 testes):**
  - Criar nota com tags, título vazio
  - Listar com paginação
  - Obter por ID, nota inexistente
  - Busca textual, filtro por tag
  - Atualizar nota, nota inexistente
  - Deletar nota, após remoção
  - Sem autenticação

## 📄 Licença

MIT
