package com.notescrud.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class JwtProvider {

    private static final Logger log = LoggerFactory.getLogger(JwtProvider.class);
    private static final Pattern DURATION_PATTERN = Pattern.compile(
        "(\\d+)\\s*(s|m|h|d)", Pattern.CASE_INSENSITIVE
    );

    private final SecretKey secretKey;
    private final Duration expiration;

    public JwtProvider(
            @Value("${jwt.secret}") String secret,
            @Value("${jwt.expires-in}") String expiresIn
    ) {
        this.secretKey = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.expiration = parseDuration(expiresIn);
        log.info("JwtProvider inicializado com expiração de {}", expiration);
    }

    public String generateToken(String userId) {
        Instant now = Instant.now();
        Instant exp = now.plus(expiration);

        return Jwts.builder()
                .subject(userId)
                .issuedAt(Date.from(now))
                .expiration(Date.from(exp))
                .signWith(secretKey)
                .compact();
    }

    public String validateToken(String token) {
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(secretKey)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            return claims.getSubject();
        } catch (JwtException | IllegalArgumentException e) {
            log.warn("Token JWT inválido: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Parses duration strings like "15m", "7d", "1h", "30s".
     * Supported units: s (seconds), m (minutes), h (hours), d (days)
     */
    private Duration parseDuration(String value) {
        if (value == null || value.isBlank()) {
            return Duration.ofDays(7); // default 7 days
        }

        Matcher matcher = DURATION_PATTERN.matcher(value.trim());
        if (!matcher.matches()) {
            log.warn("Formato de duração inválido: '{}'. Usando padrão de 7 dias.", value);
            return Duration.ofDays(7);
        }

        long amount = Long.parseLong(matcher.group(1));
        String unit = matcher.group(2).toLowerCase();

        return switch (unit) {
            case "s" -> Duration.ofSeconds(amount);
            case "m" -> Duration.ofMinutes(amount);
            case "h" -> Duration.ofHours(amount);
            case "d" -> Duration.ofDays(amount);
            default -> Duration.ofDays(7);
        };
    }
}
