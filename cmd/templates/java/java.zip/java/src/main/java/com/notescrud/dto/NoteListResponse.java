package com.notescrud.dto;

import java.util.List;

public class NoteListResponse {

    private List<NoteResponse> data;
    private Pagination pagination;

    public NoteListResponse() {}

    public NoteListResponse(List<NoteResponse> data, Pagination pagination) {
        this.data = data;
        this.pagination = pagination;
    }

    public List<NoteResponse> getData() { return data; }
    public void setData(List<NoteResponse> data) { this.data = data; }
    public Pagination getPagination() { return pagination; }
    public void setPagination(Pagination pagination) { this.pagination = pagination; }

    public static class Pagination {
        private int page;
        private int limit;
        private long total;
        private int totalPages;

        public Pagination() {}

        public Pagination(int page, int limit, long total, int totalPages) {
            this.page = page;
            this.limit = limit;
            this.total = total;
            this.totalPages = totalPages;
        }

        public int getPage() { return page; }
        public void setPage(int page) { this.page = page; }
        public int getLimit() { return limit; }
        public void setLimit(int limit) { this.limit = limit; }
        public long getTotal() { return total; }
        public void setTotal(long total) { this.total = total; }
        public int getTotalPages() { return totalPages; }
        public void setTotalPages(int totalPages) { this.totalPages = totalPages; }
    }
}
