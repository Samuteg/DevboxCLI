package com.notescrud.controller;

import com.notescrud.dto.*;
import com.notescrud.repository.DbRepository;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/notes")
public class NoteController {

    private static final Logger log = LoggerFactory.getLogger(NoteController.class);

    private final DbRepository db;

    public NoteController(DbRepository db) {
        this.db = db;
    }

    @PostMapping
    public ResponseEntity<NoteResponse> create(@Valid @RequestBody NoteRequest request,
                                                Authentication authentication) {
        String userId = authentication.getName();
        log.info("Criando nota para usuário {}: {}", userId, request.getTitle());

        String id = UUID.randomUUID().toString();
        db.insertNote(id, userId, request.getTitle(), request.getContent(), request.getTags());

        Optional<NoteResponse> note = db.findNoteById(id, userId);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(note.orElseThrow(() -> new RuntimeException("Erro ao criar nota")));
    }

    @GetMapping
    public ResponseEntity<NoteListResponse> list(
            Authentication authentication,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int limit,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String tag) {

        String userId = authentication.getName();

        if (page < 1) page = 1;
        if (limit < 1) limit = 10;
        if (limit > 100) limit = 100;

        List<NoteResponse> notes = db.findNotes(userId, page, limit, search, tag);
        long total = db.countNotes(userId, search, tag);
        int totalPages = (int) Math.ceil((double) total / limit);

        NoteListResponse.Pagination pagination = new NoteListResponse.Pagination(
                page, limit, total, totalPages
        );

        return ResponseEntity.ok(new NoteListResponse(notes, pagination));
    }

    @GetMapping("/{id}")
    public ResponseEntity<NoteResponse> getById(@PathVariable String id,
                                                 Authentication authentication) {
        String userId = authentication.getName();

        Optional<NoteResponse> note = db.findNoteById(id, userId);
        if (note.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        return ResponseEntity.ok(note.get());
    }

    @PutMapping("/{id}")
    public ResponseEntity<NoteResponse> update(@PathVariable String id,
                                                @Valid @RequestBody NoteRequest request,
                                                Authentication authentication) {
        String userId = authentication.getName();

        Optional<NoteResponse> existing = db.findNoteById(id, userId);
        if (existing.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        db.updateNote(id, userId, request.getTitle(), request.getContent(), request.getTags());

        Optional<NoteResponse> updated = db.findNoteById(id, userId);
        return ResponseEntity.ok(updated.orElseThrow(() -> new RuntimeException("Erro ao atualizar nota")));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id,
                                       Authentication authentication) {
        String userId = authentication.getName();

        Optional<NoteResponse> existing = db.findNoteById(id, userId);
        if (existing.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        db.deleteNote(id, userId);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
