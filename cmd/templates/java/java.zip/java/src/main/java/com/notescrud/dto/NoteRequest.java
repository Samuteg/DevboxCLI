package com.notescrud.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.List;

public class NoteRequest {

    @NotBlank(message = "Título é obrigatório.")
    @Size(min = 1, max = 200, message = "Título deve ter entre 1 e 200 caracteres.")
    private String title;

    @Size(max = 10000, message = "Conteúdo deve ter no máximo 10000 caracteres.")
    private String content;

    private List<String> tags;

    public NoteRequest() {}

    public NoteRequest(String title, String content, List<String> tags) {
        this.title = title;
        this.content = content;
        this.tags = tags;
    }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public List<String> getTags() { return tags; }
    public void setTags(List<String> tags) { this.tags = tags; }
}
