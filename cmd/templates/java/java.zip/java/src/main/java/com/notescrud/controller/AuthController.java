package com.notescrud.controller;

import com.notescrud.dto.*;
import com.notescrud.repository.DbRepository;
import com.notescrud.security.JwtProvider;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.HexFormat;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final DbRepository db;
    private final JwtProvider jwtProvider;
    private final PasswordEncoder passwordEncoder;
    private final int refreshTokenExpiresInDays;

    public AuthController(DbRepository db, JwtProvider jwtProvider,
                          PasswordEncoder passwordEncoder,
                          @org.springframework.beans.factory.annotation.Value("${refresh-token.expires-in-days}") int refreshTokenExpiresInDays) {
        this.db = db;
        this.jwtProvider = jwtProvider;
        this.passwordEncoder = passwordEncoder;
        this.refreshTokenExpiresInDays = refreshTokenExpiresInDays;
    }

    @PostMapping("/register")
    public ResponseEntity<UserResponse> register(@Valid @RequestBody AuthRequest request) {
        log.info("Cadastro de novo usuário: {}", request.getEmail());

        if (request.getName() == null || request.getName().isBlank()) {
            throw new IllegalArgumentException("Nome é obrigatório.");
        }

        // Check if email already exists
        Optional<UserResponse> existing = db.findUserByEmail(request.getEmail());
        if (existing.isPresent()) {
            throw new IllegalArgumentException("E-mail já cadastrado.");
        }

        String id = UUID.randomUUID().toString();
        String passwordHash = passwordEncoder.encode(request.getPassword());

        db.insertUser(id, request.getName(), request.getEmail(), passwordHash);

        UserResponse response = new UserResponse(id, request.getName(), request.getEmail());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest request) {
        log.info("Login do usuário: {}", request.getEmail());

        // Find user and verify password
        Optional<String> passwordHash = db.findPasswordByEmail(request.getEmail());
        if (passwordHash.isEmpty() || !passwordEncoder.matches(request.getPassword(), passwordHash.get())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(null);
        }

        Optional<UserResponse> userOpt = db.findUserByEmail(request.getEmail());
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(null);
        }

        UserResponse user = userOpt.get();
        String accessToken = jwtProvider.generateToken(user.getId());

        // Generate refresh token
        String refreshToken = UUID.randomUUID().toString();
        String refreshTokenHash = hashToken(refreshToken);
        Instant expiresAt = Instant.now().plus(refreshTokenExpiresInDays, ChronoUnit.DAYS);
        db.insertRefreshToken(UUID.randomUUID().toString(), user.getId(), refreshTokenHash, expiresAt);

        AuthResponse response = new AuthResponse(accessToken, refreshToken, user);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@RequestBody AuthRequest request) {
        String rawToken = request.getRefreshToken();
        if (rawToken == null || rawToken.isBlank()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ErrorResponse(401, "Refresh token é obrigatório.", "Unauthorized"));
        }

        String tokenHash = hashToken(rawToken);

        Optional<String> userIdOpt = db.findRefreshTokenUserId(tokenHash);
        if (userIdOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ErrorResponse(401, "Refresh token inválido ou expirado.", "Unauthorized"));
        }

        String userId = userIdOpt.get();

        // Rotate: delete old token
        db.deleteRefreshToken(tokenHash);

        // Generate new tokens
        String newAccessToken = jwtProvider.generateToken(userId);
        String newRefreshToken = UUID.randomUUID().toString();
        String newRefreshTokenHash = hashToken(newRefreshToken);
        Instant expiresAt = Instant.now().plus(refreshTokenExpiresInDays, ChronoUnit.DAYS);
        db.insertRefreshToken(UUID.randomUUID().toString(), userId, newRefreshTokenHash, expiresAt);

        return ResponseEntity.ok(new AuthResponse(newAccessToken, newRefreshToken, null));
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        String userId = authentication.getName();
        db.deleteAllRefreshTokensByUserId(userId);

        log.info("Logout do usuário: {}", userId);
        return ResponseEntity.ok(java.util.Map.of("message", "Logout realizado com sucesso."));
    }

    @GetMapping("/me")
    public ResponseEntity<UserResponse> me(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        String userId = authentication.getName();
        Optional<UserResponse> userOpt = db.findUserById(userId);

        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        return ResponseEntity.ok(userOpt.get());
    }

    private String hashToken(String token) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(token.getBytes());
            return HexFormat.of().formatHex(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 não disponível", e);
        }
    }
}
