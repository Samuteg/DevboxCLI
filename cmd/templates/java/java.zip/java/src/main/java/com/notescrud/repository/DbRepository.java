package com.notescrud.repository;

import com.notescrud.dto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

@Repository
public class DbRepository {

    private static final Logger log = LoggerFactory.getLogger(DbRepository.class);

    private final JdbcTemplate jdbc;

    public DbRepository(DataSource dataSource) {
        this.jdbc = new JdbcTemplate(dataSource);
        initTables();
    }

    private void initTables() {
        log.info("Inicializando tabelas do banco de dados...");

        jdbc.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """);

        jdbc.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL DEFAULT '',
                tags TEXT NOT NULL DEFAULT '[]',
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                updated_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        """);

        jdbc.execute("""
            CREATE TABLE IF NOT EXISTS refresh_tokens (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                token_hash TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        """);

        log.info("Tabelas inicializadas com sucesso.");
    }

    // ── Users ──────────────────────────────────────────────────────────────────

    public Optional<UserResponse> findUserByEmail(String email) {
        try {
            UserResponse user = jdbc.queryForObject(
                "SELECT id, name, email FROM users WHERE email = ?",
                this::mapUser,
                email
            );
            return Optional.ofNullable(user);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public Optional<UserResponse> findUserById(String id) {
        try {
            UserResponse user = jdbc.queryForObject(
                "SELECT id, name, email FROM users WHERE id = ?",
                this::mapUser,
                id
            );
            return Optional.ofNullable(user);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public Optional<String> findPasswordByEmail(String email) {
        try {
            String password = jdbc.queryForObject(
                "SELECT password FROM users WHERE email = ?",
                String.class,
                email
            );
            return Optional.ofNullable(password);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public void insertUser(String id, String name, String email, String passwordHash) {
        jdbc.update(
            "INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)",
            id, name, email, passwordHash
        );
    }

    // ── Notes ──────────────────────────────────────────────────────────────────

    public List<NoteResponse> findNotes(String userId, int page, int limit,
                                         String search, String tag) {
        int offset = (page - 1) * limit;

        StringBuilder sql = new StringBuilder(
            "SELECT id, title, content, tags, created_at, updated_at FROM notes WHERE user_id = ?"
        );

        List<Object> params = new ArrayList<>();
        params.add(userId);

        if (search != null && !search.isBlank()) {
            sql.append(" AND (title LIKE ? OR content LIKE ?)");
            String pattern = "%" + search.trim() + "%";
            params.add(pattern);
            params.add(pattern);
        }

        if (tag != null && !tag.isBlank()) {
            sql.append(" AND tags LIKE ?");
            params.add("%\"" + tag.trim() + "\"%");
        }

        sql.append(" ORDER BY created_at DESC LIMIT ? OFFSET ?");
        params.add(limit);
        params.add(offset);

        return jdbc.query(sql.toString(), this::mapNote, params.toArray());
    }

    public long countNotes(String userId, String search, String tag) {
        StringBuilder sql = new StringBuilder(
            "SELECT COUNT(*) FROM notes WHERE user_id = ?"
        );

        List<Object> params = new ArrayList<>();
        params.add(userId);

        if (search != null && !search.isBlank()) {
            sql.append(" AND (title LIKE ? OR content LIKE ?)");
            String pattern = "%" + search.trim() + "%";
            params.add(pattern);
            params.add(pattern);
        }

        if (tag != null && !tag.isBlank()) {
            sql.append(" AND tags LIKE ?");
            params.add("%\"" + tag.trim() + "\"%");
        }

        Long count = jdbc.queryForObject(sql.toString(), Long.class, params.toArray());
        return count != null ? count : 0L;
    }

    public Optional<NoteResponse> findNoteById(String id, String userId) {
        try {
            NoteResponse note = jdbc.queryForObject(
                "SELECT id, title, content, tags, created_at, updated_at FROM notes WHERE id = ? AND user_id = ?",
                this::mapNote,
                id, userId
            );
            return Optional.ofNullable(note);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public void insertNote(String id, String userId, String title, String content, List<String> tags) {
        jdbc.update(
            "INSERT INTO notes (id, user_id, title, content, tags) VALUES (?, ?, ?, ?, ?)",
            id, userId, title, content != null ? content : "", serializeTags(tags)
        );
    }

    public void updateNote(String id, String userId, String title, String content, List<String> tags) {
        jdbc.update(
            "UPDATE notes SET title = ?, content = ?, tags = ?, updated_at = datetime('now') WHERE id = ? AND user_id = ?",
            title, content != null ? content : "", serializeTags(tags), id, userId
        );
    }

    public void deleteNote(String id, String userId) {
        jdbc.update("DELETE FROM notes WHERE id = ? AND user_id = ?", id, userId);
    }

    // ── Refresh Tokens ─────────────────────────────────────────────────────────

    public Optional<String> findRefreshTokenUserId(String tokenHash) {
        try {
            // Also check expiration
            String userId = jdbc.queryForObject(
                "SELECT user_id FROM refresh_tokens WHERE token_hash = ? AND expires_at > datetime('now')",
                String.class,
                tokenHash
            );
            return Optional.ofNullable(userId);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public void insertRefreshToken(String id, String userId, String tokenHash, Instant expiresAt) {
        jdbc.update(
            "INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at) VALUES (?, ?, ?, ?)",
            id, userId, tokenHash, Timestamp.from(expiresAt).toString()
        );
    }

    public void deleteRefreshToken(String tokenHash) {
        jdbc.update("DELETE FROM refresh_tokens WHERE token_hash = ?", tokenHash);
    }

    public void deleteAllRefreshTokensByUserId(String userId) {
        jdbc.update("DELETE FROM refresh_tokens WHERE user_id = ?", userId);
    }

    // ── Mappers ────────────────────────────────────────────────────────────────

    private UserResponse mapUser(ResultSet rs, int rowNum) throws SQLException {
        UserResponse user = new UserResponse();
        user.setId(rs.getString("id"));
        user.setName(rs.getString("name"));
        user.setEmail(rs.getString("email"));
        return user;
    }

    private NoteResponse mapNote(ResultSet rs, int rowNum) throws SQLException {
        NoteResponse note = new NoteResponse();
        note.setId(rs.getString("id"));
        note.setTitle(rs.getString("title"));
        note.setContent(rs.getString("content"));
        note.setTags(deserializeTags(rs.getString("tags")));

        String createdAt = rs.getString("created_at");
        String updatedAt = rs.getString("updated_at");
        note.setCreatedAt(parseInstant(createdAt));
        note.setUpdatedAt(parseInstant(updatedAt));

        return note;
    }

    private Instant parseInstant(String dateTime) {
        if (dateTime == null) return Instant.now();
        // SQLite returns datetime in format "YYYY-MM-DD HH:MM:SS"
        return Instant.parse(dateTime.replace(" ", "T") + "Z");
    }

    private String serializeTags(List<String> tags) {
        if (tags == null) return "[]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < tags.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append("\"").append(tags.get(i).replace("\"", "\\\"")).append("\"");
        }
        sb.append("]");
        return sb.toString();
    }

    private List<String> deserializeTags(String tags) {
        if (tags == null || tags.isBlank() || tags.equals("[]")) {
            return new ArrayList<>();
        }
        // Simple JSON array parsing for strings
        List<String> result = new ArrayList<>();
        String content = tags.substring(1, tags.length() - 1); // remove [ ]
        if (content.isBlank()) return result;

        int i = 0;
        while (i < content.length()) {
            if (content.charAt(i) == '"') {
                StringBuilder sb = new StringBuilder();
                i++;
                while (i < content.length() && content.charAt(i) != '"') {
                    if (content.charAt(i) == '\\' && i + 1 < content.length()) {
                        i++;
                    }
                    sb.append(content.charAt(i));
                    i++;
                }
                result.add(sb.toString());
                i++;
            } else {
                i++;
            }
        }
        return result;
    }
}
