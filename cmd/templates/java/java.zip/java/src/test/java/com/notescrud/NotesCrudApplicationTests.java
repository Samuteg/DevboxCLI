package com.notescrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Teste básico de contexto da aplicação Spring Boot.
 */
@SpringBootTest
class NotesCrudApplicationTests {

    @Test
    void contextLoads() {
    }
}
