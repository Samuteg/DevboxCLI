package com.notescrud;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.notescrud.dto.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class NoteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private static String token;
    private static String noteId;

    @BeforeAll
    static void setup(@Autowired MockMvc mockMvc, @Autowired ObjectMapper objectMapper) throws Exception {
        // Cria usuário e obtém token para os testes
        String email = "notes-test-" + System.currentTimeMillis() + "@email.com";

        AuthRequest registerRequest = new AuthRequest("Notes Tester", email, "123456", null);
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(registerRequest)));

        AuthRequest loginRequest = new AuthRequest(null, email, "123456", null);
        var result = mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
            .andReturn();

        String json = result.getResponse().getContentAsString();
        AuthResponse response = objectMapper.readValue(json, AuthResponse.class);
        token = response.getAccessToken();
    }

    // ── Create ─────────────────────────────────────────────────────────────────

    @Test
    @Order(1)
    void deveCriarNotaComTags() throws Exception {
        NoteRequest request = new NoteRequest("Minha nota", "Conteúdo legal",
                List.of("estudo", "spring"));

        var result = mockMvc.perform(post("/api/notes")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.title").value("Minha nota"))
            .andExpect(jsonPath("$.tags[0]").value("estudo"))
            .andExpect(jsonPath("$.tags[1]").value("spring"))
            .andExpect(jsonPath("$.createdAt").isNotEmpty())
            .andExpect(jsonPath("$.updatedAt").isNotEmpty())
            .andReturn();

        String json = result.getResponse().getContentAsString();
        NoteResponse note = objectMapper.readValue(json, NoteResponse.class);
        noteId = note.getId();
    }

    @Test
    @Order(2)
    void deveRejeitarTituloVazio() throws Exception {
        NoteRequest request = new NoteRequest("", "algo", null);

        mockMvc.perform(post("/api/notes")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isBadRequest());
    }

    // ── Read (list) ────────────────────────────────────────────────────────────

    @Test
    @Order(3)
    void deveListarNotasComPaginacao() throws Exception {
        var result = mockMvc.perform(get("/api/notes?page=1&limit=10")
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.data").isArray())
            .andExpect(jsonPath("$.pagination").isNotEmpty())
            .andExpect(jsonPath("$.pagination.page").value(1))
            .andExpect(jsonPath("$.pagination.limit").value(10))
            .andReturn();

        String json = result.getResponse().getContentAsString();
        NoteListResponse response = objectMapper.readValue(json, NoteListResponse.class);
        Assertions.assertTrue(response.getData().size() >= 1);
    }

    // ── Read (by id) ───────────────────────────────────────────────────────────

    @Test
    @Order(4)
    void deveRetornarNotaPorId() throws Exception {
        mockMvc.perform(get("/api/notes/" + noteId)
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(noteId));
    }

    @Test
    @Order(5)
    void deveRetornar404ParaIdInexistente() throws Exception {
        mockMvc.perform(get("/api/notes/id-inexistente")
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isNotFound());
    }

    // ── Search ─────────────────────────────────────────────────────────────────

    @Test
    @Order(6)
    void deveBuscarNotasPorTexto() throws Exception {
        var result = mockMvc.perform(get("/api/notes?search=Conteúdo")
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isOk())
            .andReturn();

        String json = result.getResponse().getContentAsString();
        NoteListResponse response = objectMapper.readValue(json, NoteListResponse.class);
        Assertions.assertTrue(response.getData().size() >= 1);
    }

    // ── Filter by tag ──────────────────────────────────────────────────────────

    @Test
    @Order(7)
    void deveFiltrarPorTag() throws Exception {
        var result = mockMvc.perform(get("/api/notes?tag=estudo")
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isOk())
            .andReturn();

        String json = result.getResponse().getContentAsString();
        NoteListResponse response = objectMapper.readValue(json, NoteListResponse.class);

        for (NoteResponse note : response.getData()) {
            Assertions.assertTrue(note.getTags().contains("estudo"));
        }
    }

    // ── Update ─────────────────────────────────────────────────────────────────

    @Test
    @Order(8)
    void deveAtualizarNota() throws Exception {
        NoteRequest request = new NoteRequest("Título atualizado", "Conteúdo atualizado",
                List.of("estudo", "node"));

        var result = mockMvc.perform(put("/api/notes/" + noteId)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.title").value("Título atualizado"))
            .andExpect(jsonPath("$.tags[1]").value("node"))
            .andExpect(jsonPath("$.createdAt").isNotEmpty())
            .andReturn();

        String json = result.getResponse().getContentAsString();
        NoteResponse note = objectMapper.readValue(json, NoteResponse.class);
        Assertions.assertNotNull(note.getCreatedAt());
    }

    @Test
    @Order(9)
    void deveRetornar404ParaNotaInexistente() throws Exception {
        NoteRequest request = new NoteRequest("X", "Y", null);

        mockMvc.perform(put("/api/notes/id-fake")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isNotFound());
    }

    // ── Delete ─────────────────────────────────────────────────────────────────

    @Test
    @Order(10)
    void deveRemoverNota() throws Exception {
        mockMvc.perform(delete("/api/notes/" + noteId)
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isNoContent());
    }

    @Test
    @Order(11)
    void deveRetornar404AposRemocao() throws Exception {
        mockMvc.perform(delete("/api/notes/" + noteId)
                .header("Authorization", "Bearer " + token))
            .andExpect(status().isNotFound());
    }

    // ── Sem autenticação ───────────────────────────────────────────────────────

    @Test
    @Order(12)
    void deveRejeitarSemToken() throws Exception {
        mockMvc.perform(get("/api/notes"))
            .andExpect(status().isUnauthorized());
    }
}
