package com.notescrud;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.notescrud.dto.AuthRequest;
import com.notescrud.dto.AuthResponse;
import com.notescrud.dto.UserResponse;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private static final String USER_NAME = "Teste";
    private static final String USER_EMAIL = "auth-test-" + System.currentTimeMillis() + "@email.com";
    private static final String USER_PASSWORD = "123456";

    private static String accessToken;
    private static String refreshToken;

    // ── Register ───────────────────────────────────────────────────────────────

    @Test
    @Order(1)
    void deveCadastrarNovoUsuario() throws Exception {
        AuthRequest request = new AuthRequest(USER_NAME, USER_EMAIL, USER_PASSWORD, null);

        var result = mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.id").isNotEmpty())
            .andExpect(jsonPath("$.name").value(USER_NAME))
            .andExpect(jsonPath("$.email").value(USER_EMAIL))
            .andExpect(jsonPath("$.password").doesNotExist())
            .andReturn();

        String json = result.getResponse().getContentAsString();
        UserResponse user = objectMapper.readValue(json, UserResponse.class);
        Assertions.assertNotNull(user.getId());
    }

    @Test
    @Order(2)
    void deveRejeitarEmailDuplicado() throws Exception {
        AuthRequest request = new AuthRequest(USER_NAME, USER_EMAIL, USER_PASSWORD, null);

        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.message").value("E-mail já cadastrado."));
    }

    @Test
    @Order(3)
    void deveRejeitarDadosInvalidos() throws Exception {
        AuthRequest request = new AuthRequest("", "invalido", "12", null);

        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isBadRequest());
    }

    // ── Login ──────────────────────────────────────────────────────────────────

    @Test
    @Order(4)
    void deveAutenticarERetornarTokens() throws Exception {
        AuthRequest request = new AuthRequest(null, USER_EMAIL, USER_PASSWORD, null);

        var result = mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.accessToken").isNotEmpty())
            .andExpect(jsonPath("$.refreshToken").isNotEmpty())
            .andExpect(jsonPath("$.user.email").value(USER_EMAIL))
            .andReturn();

        String json = result.getResponse().getContentAsString();
        AuthResponse response = objectMapper.readValue(json, AuthResponse.class);
        accessToken = response.getAccessToken();
        refreshToken = response.getRefreshToken();

        Assertions.assertNotNull(accessToken);
        Assertions.assertNotNull(refreshToken);
    }

    @Test
    @Order(5)
    void deveRejeitarCredenciaisInvalidas() throws Exception {
        AuthRequest request = new AuthRequest(null, USER_EMAIL, "senha_errada", null);

        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isUnauthorized());
    }

    // ── Me ─────────────────────────────────────────────────────────────────────

    @Test
    @Order(6)
    void deveRetornarDadosDoUsuario() throws Exception {
        mockMvc.perform(get("/api/auth/me")
                .header("Authorization", "Bearer " + accessToken))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.email").value(USER_EMAIL));
    }

    @Test
    @Order(7)
    void deveRejeitarSemToken() throws Exception {
        mockMvc.perform(get("/api/auth/me"))
            .andExpect(status().isUnauthorized());
    }

    // ── Refresh ────────────────────────────────────────────────────────────────

    @Test
    @Order(8)
    void deveRenovarAccessToken() throws Exception {
        AuthRequest request = new AuthRequest(null, null, null, refreshToken);

        var result = mockMvc.perform(post("/api/auth/refresh")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.accessToken").isNotEmpty())
            .andExpect(jsonPath("$.refreshToken").isNotEmpty())
            .andReturn();

        String json = result.getResponse().getContentAsString();
        AuthResponse response = objectMapper.readValue(json, AuthResponse.class);

        // Verifica rotação
        Assertions.assertNotEquals(refreshToken, response.getRefreshToken());

        // Atualiza para próximos testes
        accessToken = response.getAccessToken();
        refreshToken = response.getRefreshToken();
    }

    @Test
    @Order(9)
    void deveRejeitarRefreshTokenInvalido() throws Exception {
        AuthRequest request = new AuthRequest(null, null, null,
                "00000000-0000-0000-0000-000000000000");

        mockMvc.perform(post("/api/auth/refresh")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isUnauthorized());
    }

    // ── Logout ─────────────────────────────────────────────────────────────────

    @Test
    @Order(10)
    void deveRevogarRefreshTokens() throws Exception {
        mockMvc.perform(post("/api/auth/logout")
                .header("Authorization", "Bearer " + accessToken))
            .andExpect(status().isOk());
    }

    @Test
    @Order(11)
    void deveRejeitarRefreshAposLogout() throws Exception {
        AuthRequest request = new AuthRequest(null, null, null, refreshToken);

        mockMvc.perform(post("/api/auth/refresh")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isUnauthorized());
    }
}
