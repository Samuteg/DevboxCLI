# frozen_string_literal: true

require "dotenv/load" unless ENV["RACK_ENV"] == "production"
require "sinatra/base"
require "sinatra/json"
require "rack/cors"
require "rack/attack"
require "json"
require "logger"
require "securerandom"
require "time"
require "bcrypt"
require "jwt"
require "digest"

require_relative "lib/logger_config"
require_relative "lib/db"
require_relative "helpers/auth_helpers"
require_relative "routes/auth"
require_relative "routes/notes"

# ── Configuração do Rack::Attack (Rate Limiting) ────────────────────────

unless ENV["RACK_ENV"] == "test"
  class Rack::Attack
    throttle("api", limit: 100, period: 60) do |req|
      req.ip
    end

    self.throttled_response = lambda do |env|
      match_data = env["rack.attack.match_data"]
      retry_after = match_data ? match_data[:period] : 60
      body = { message: "Muitas requisições. Tente novamente em #{retry_after} segundos." }.to_json

      [429, { "Content-Type" => "application/json" }, [body]]
    end
  end
end

# ── Aplicação Sinatra ───────────────────────────────────────────────────

class NotesApp < Sinatra::Base
  # ── Configuração ─────────────────────────────────────────────────────

  configure do
    set :port, ENV.fetch("PORT", 3000).to_i
    set :bind, "0.0.0.0"
    set :server, :puma
    set :show_exceptions, false
    set :logger, LoggerConfig.build
    set :raise_errors, false
    set :jwt_secret, ENV.fetch("JWT_SECRET", "fallback-secret")
    set :jwt_expires_in, ENV.fetch("JWT_EXPIRES_IN", "7d")
    set :refresh_expires_in_days, ENV.fetch("REFRESH_TOKEN_EXPIRES_IN_DAYS", 30).to_i

    # Inicializa o banco SQLite
    Db.init
  end

  # ── Middleware ────────────────────────────────────────────────────────

  use Rack::Cors do
    allow do
      origins "*"
      resource "*",
               headers: :any,
               methods: %i[get post put patch delete options head]
    end
  end

  use Rack::Attack unless ENV["RACK_ENV"] == "test"

  # ── Helpers ──────────────────────────────────────────────────────────

  helpers AuthHelpers

  # Helper para fazer parse do JSON do body da requisição
  helpers do
    def json_body
      @json_body
    end
  end

  # ── Parsing de JSON no body das requisições ─────────────────────────

  before do
    content_type :json

    if request.content_type&.include?("application/json")
      body = request.body.read
      @json_body = body.empty? ? {} : (JSON.parse(body) rescue {})
    elsif request.post? || request.put? || request.patch?
      # Tenta parsear mesmo sem content-type para testes
      body = request.body.read
      @json_body = body.empty? ? {} : (JSON.parse(body) rescue {})
    end
  end

  # ── Tratamento de erros ─────────────────────────────────────────────

  not_found do
    { message: "Rota não encontrada." }.to_json
  end

  error do
    logger.error env["sinatra.error"]
    status 500
    { message: "Erro interno do servidor." }.to_json
  end

  # ── Health Check ─────────────────────────────────────────────────────

  get "/health" do
    { status: "ok", timestamp: Time.now.utc.iso8601 }.to_json
  end

  # ── OpenAPI / Swagger ────────────────────────────────────────────────

  get "/api/openapi.json" do
    send_file File.join(__dir__, "openapi.json")
  end

  get "/docs" do
    content_type :html
    <<~HTML
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Notes CRUD API - Swagger</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css" />
      </head>
      <body>
        <div id="swagger-ui"></div>
        <script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
        <script>
          SwaggerUIBundle({
            url: '/api/openapi.json',
            dom_id: '#swagger-ui',
            deepLinking: true,
            docExpansion: 'list'
          });
        </script>
      </body>
      </html>
    HTML
  end

  # ── Rotas ────────────────────────────────────────────────────────────

  register AuthRoutes
  register NoteRoutes
end

# ── Inicialização (apenas quando executado diretamente) ─────────────────

if __FILE__ == $PROGRAM_NAME
  port = ENV.fetch("PORT", 3000).to_i

  NotesApp.run! do |server|
    puts "🚀  Servidor rodando em http://localhost:#{port}"
    puts "📄  Documentação Swagger em http://localhost:#{port}/docs"
  end
end
