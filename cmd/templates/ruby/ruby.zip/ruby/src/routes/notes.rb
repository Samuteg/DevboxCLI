# frozen_string_literal: true

require "securerandom"
require "time"

# Rotas do CRUD de notas (protegidas por JWT).
#
# GET    /api/notes      - Listar notas (paginação, busca, filtro tag)
# GET    /api/notes/:id  - Obter nota por ID
# POST   /api/notes      - Criar nova nota
# PUT    /api/notes/:id  - Atualizar nota
# DELETE /api/notes/:id  - Remover nota
module NoteRoutes
  def self.registered(app)
    # ─── GET /api/notes ────────────────────────────────────────────────────────

    app.get "/api/notes" do
      authenticate!

      page  = (params["page"] || 1).to_i.clamp(1, Float::INFINITY)
      limit = (params["limit"] || 10).to_i.clamp(1, 100)
      search = params["search"]
      tag   = params["tag"]

      result = Db.list_notes(
        user_id: current_user["id"],
        search: search,
        tag: tag,
        page: page,
        limit: limit
      )

      result.to_json
    end

    # ─── GET /api/notes/:id ────────────────────────────────────────────────────

    app.get "/api/notes/:id" do
      authenticate!

      note = Db.find_note_by_id(params[:id], current_user["id"])
      halt 404, { message: "Nota não encontrada." }.to_json unless note

      note.to_json
    end

    # ─── POST /api/notes ───────────────────────────────────────────────────────

    app.post "/api/notes" do
      authenticate!
      data = json_body

      # Validação
      errors = {}
      errors[:title] = "Título é obrigatório" if data["title"].to_s.strip.empty?
      errors[:title] = "Título deve ter no máximo 200 caracteres" if data["title"].to_s.length > 200
      errors[:content] = "Conteúdo é obrigatório" if data["content"].to_s.strip.empty?
      if data["tags"].is_a?(Array)
        errors[:tags] = "Cada tag deve ter no máximo 50 caracteres" if data["tags"].any? { |t| t.to_s.length > 50 }
        errors[:tags] = "Máximo de 20 tags" if data["tags"].length > 20
      end

      halt 400, { message: "Dados inválidos.", errors: errors }.to_json unless errors.empty?

      id = SecureRandom.uuid
      tags = data["tags"].is_a?(Array) ? data["tags"] : []

      note = Db.create_note(
        id: id,
        user_id: current_user["id"],
        title: data["title"].strip,
        content: data["content"],
        tags: tags
      )

      status 201
      note.to_json
    end

    # ─── PUT /api/notes/:id ────────────────────────────────────────────────────

    app.put "/api/notes/:id" do
      authenticate!
      data = json_body

      # Validação
      errors = {}
      errors[:title] = "Título é obrigatório" if data["title"].to_s.strip.empty?
      errors[:title] = "Título deve ter no máximo 200 caracteres" if data["title"].to_s.length > 200
      errors[:content] = "Conteúdo é obrigatório" if data["content"].to_s.strip.empty?
      if data["tags"].is_a?(Array)
        errors[:tags] = "Cada tag deve ter no máximo 50 caracteres" if data["tags"].any? { |t| t.to_s.length > 50 }
        errors[:tags] = "Máximo de 20 tags" if data["tags"].length > 20
      end

      halt 400, { message: "Dados inválidos.", errors: errors }.to_json unless errors.empty?

      tags = data["tags"].is_a?(Array) ? data["tags"] : []

      updated = Db.update_note(
        id: params[:id],
        user_id: current_user["id"],
        title: data["title"].strip,
        content: data["content"],
        tags: tags
      )

      halt 404, { message: "Nota não encontrada." }.to_json unless updated

      updated.to_json
    end

    # ─── DELETE /api/notes/:id ─────────────────────────────────────────────────

    app.delete "/api/notes/:id" do
      authenticate!

      deleted = Db.delete_note(params[:id], current_user["id"])
      halt 404, { message: "Nota não encontrada." }.to_json unless deleted

      status 204
      nil
    end
  end
end
