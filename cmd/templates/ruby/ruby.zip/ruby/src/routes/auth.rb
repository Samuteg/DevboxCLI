# frozen_string_literal: true

require "bcrypt"
require "securerandom"
require "time"

# Rotas de autenticação.
#
# POST /api/auth/register  - Cadastrar um novo usuário
# POST /api/auth/login     - Autenticar e obter tokens
# POST /api/auth/refresh   - Renovar access token
# POST /api/auth/logout    - Revogar refresh tokens
# GET  /api/auth/me        - Dados do usuário autenticado
module AuthRoutes
  def self.registered(app)
    # ─── POST /api/auth/register ──────────────────────────────────────────────

    app.post "/api/auth/register" do
      data = json_body

      # Validação dos campos
      errors = {}
      errors[:name] = "Nome é obrigatório" if data["name"].to_s.strip.empty?
      unless data["email"].to_s.match?(/\A[^@\s]+@[^@\s]+\z/)
        errors[:email] = "E-mail inválido"
      end
      if data["password"].to_s.length < 6
        errors[:password] = "Senha deve ter no mínimo 6 caracteres"
      end

      halt 400, { message: "Dados inválidos.", errors: errors }.to_json unless errors.empty?

      # Verifica duplicidade de e-mail
      halt 409, { message: "E-mail já cadastrado." }.to_json if Db.find_user_by_email(data["email"])

      # Cria o usuário
      hashed_password = BCrypt::Password.create(data["password"])
      id = SecureRandom.uuid
      Db.create_user(id: id, name: data["name"].strip, email: data["email"].strip, password: hashed_password)

      status 201
      { id: id, name: data["name"].strip, email: data["email"].strip }.to_json
    end

    # ─── POST /api/auth/login ─────────────────────────────────────────────────

    app.post "/api/auth/login" do
      data = json_body

      # Validação dos campos
      errors = {}
      errors[:email] = "E-mail é obrigatório" unless data["email"].to_s.match?(/.+/)
      errors[:password] = "Senha é obrigatória" unless data["password"].to_s.match?(/.+/)
      halt 400, { message: "Dados inválidos.", errors: errors }.to_json unless errors.empty?

      user = Db.find_user_by_email(data["email"])
      halt 401, { message: "Credenciais inválidas." }.to_json unless user

      pw = BCrypt::Password.new(user["password"])
      halt 401, { message: "Credenciais inválidas." }.to_json unless pw == data["password"]

      # Gera access token
      access_token = generate_access_token(user)

      # Gera refresh token
      raw_refresh_token = generate_refresh_token
      token_hash = hash_token(raw_refresh_token)
      expires_at = (Time.now.utc + (settings.refresh_expires_in_days || 30) * 86_400).iso8601(3)

      Db.save_refresh_token(
        id: SecureRandom.uuid,
        user_id: user["id"],
        token_hash: token_hash,
        expires_at: expires_at
      )

      {
        accessToken: access_token,
        refreshToken: raw_refresh_token,
        user: { id: user["id"], name: user["name"], email: user["email"] }
      }.to_json
    end

    # ─── POST /api/auth/refresh ───────────────────────────────────────────────

    app.post "/api/auth/refresh" do
      data = json_body
      halt 400, { message: "Refresh token inválido.", errors: { refreshToken: "Campo obrigatório" } }.to_json unless data["refreshToken"]

      token_hash = hash_token(data["refreshToken"])
      stored = Db.find_refresh_token(token_hash)
      halt 401, { message: "Refresh token inválido ou já utilizado." }.to_json unless stored

      # Verifica expiração
      if Time.parse(stored["expires_at"]) < Time.now.utc
        Db.revoke_refresh_token(stored["id"])
        halt 401, { message: "Refresh token expirado." }.to_json
      end

      # Rotação: revoga o token atual
      Db.revoke_refresh_token(stored["id"])

      # Busca o usuário
      user = Db.find_user_by_id(stored["user_id"])
      halt 401, { message: "Usuário não encontrado." }.to_json unless user

      # Gera novo access token
      new_access_token = generate_access_token(user)

      # Gera novo refresh token
      new_raw_refresh_token = generate_refresh_token
      new_token_hash = hash_token(new_raw_refresh_token)
      new_expires_at = (Time.now.utc + (settings.refresh_expires_in_days || 30) * 86_400).iso8601(3)

      Db.save_refresh_token(
        id: SecureRandom.uuid,
        user_id: user["id"],
        token_hash: new_token_hash,
        expires_at: new_expires_at
      )

      {
        accessToken: new_access_token,
        refreshToken: new_raw_refresh_token
      }.to_json
    end

    # ─── POST /api/auth/logout ────────────────────────────────────────────────

    app.post "/api/auth/logout" do
      authenticate!
      Db.revoke_all_user_refresh_tokens(current_user["id"])
      { message: "Logout realizado com sucesso." }.to_json
    end

    # ─── GET /api/auth/me ──────────────────────────────────────────────────────

    app.get "/api/auth/me" do
      authenticate!
      { id: current_user["id"], name: current_user["name"], email: current_user["email"] }.to_json
    end
  end
end
