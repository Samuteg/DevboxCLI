# frozen_string_literal: true

# ── Ambiente de teste ──────────────────────────────────────────────────────────
ENV["RACK_ENV"] = "test"
ENV["DB_PATH"] = ":memory:"
ENV["JWT_SECRET"] = "test-secret"
ENV["JWT_EXPIRES_IN"] = "1h"
ENV["REFRESH_TOKEN_EXPIRES_IN_DAYS"] = "1"

# ── Carrega a aplicação ────────────────────────────────────────────────────────
require_relative "../app"

# Reinicializa o banco em memória para cada execução de teste
Db.reset!
Db.init

# ── Bibliotecas de teste ──────────────────────────────────────────────────────
require "minitest/autorun"
require "minitest/reporters"
require "rack/test"
require "json"

Minitest::Reporters.use! [Minitest::Reporters::SpecReporter.new]

# ── Classe base para os testes ─────────────────────────────────────────────────
class AppTest < Minitest::Test
  include Rack::Test::Methods

  def app
    NotesApp
  end

  # Helper para fazer requisição POST com JSON
  def post_json(path, body = {}, headers = {})
    post path, body.to_json, { "CONTENT_TYPE" => "application/json" }.merge(headers)
  end

  # Helper para fazer requisição GET autenticada
  def get_authed(path, token, headers = {})
    get path, {}, { "HTTP_AUTHORIZATION" => "Bearer #{token}" }.merge(headers)
  end

  # Helper para fazer requisição POST autenticada com JSON
  def post_authed_json(path, body = {}, token = nil, headers = {})
    h = { "CONTENT_TYPE" => "application/json" }
    h["HTTP_AUTHORIZATION"] = "Bearer #{token}" if token
    post path, body.to_json, h.merge(headers)
  end

  # Helper para fazer requisição PUT autenticada com JSON
  def put_authed_json(path, body = {}, token = nil, headers = {})
    h = { "CONTENT_TYPE" => "application/json" }
    h["HTTP_AUTHORIZATION"] = "Bearer #{token}" if token
    put path, body.to_json, h.merge(headers)
  end

  # Helper para fazer requisição DELETE autenticada
  def delete_authed(path, token = nil, headers = {})
    h = {}
    h["HTTP_AUTHORIZATION"] = "Bearer #{token}" if token
    delete path, {}, h.merge(headers)
  end

  # Retorna o corpo da resposta como hash
  def json_body
    JSON.parse(last_response.body)
  rescue JSON::ParserError
    {}
  end
end
