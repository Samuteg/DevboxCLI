# frozen_string_literal: true

require_relative "test_helper"

class NotesTest < AppTest
  @@token = nil
  @@note_id = nil

  # ── Setup ─────────────────────────────────────────────────────────────────────
  # Cria um usuário e obtém token uma única vez para todos os testes

  def setup
    super
    return if @@token

    email = "notes-test-#{Time.now.to_i}-#{rand(1000)}@email.com"

    post_json "/api/auth/register", {
      name: "Notes Tester",
      email: email,
      password: "123456"
    }

    post_json "/api/auth/login", {
      email: email,
      password: "123456"
    }

    body = JSON.parse(last_response.body)
    @@token = body["accessToken"]
  end

  # ── Create ───────────────────────────────────────────────────────────────────

  test "POST /api/notes — deve criar nota com tags" do
    post_authed_json "/api/notes", {
      title: "Minha nota",
      content: "Conteúdo legal",
      tags: ["estudo", "sinatra"]
    }, @@token

    assert_equal 201, last_response.status
    body = json_body
    assert_equal "Minha nota", body["title"]
    assert_equal ["estudo", "sinatra"], body["tags"]
    assert body["createdAt"]
    assert body["updatedAt"]
    assert body["id"]

    @@note_id = body["id"]
  end

  test "POST /api/notes — deve rejeitar título vazio" do
    post_authed_json "/api/notes", {
      title: "",
      content: "algo"
    }, @@token

    assert_equal 400, last_response.status
    body = json_body
    assert body["errors"]
    assert body["errors"]["title"]
  end

  # ── Read (list) ──────────────────────────────────────────────────────────────

  test "GET /api/notes — deve listar notas com paginação" do
    get_authed "/api/notes?page=1&limit=10", @@token

    assert_equal 200, last_response.status
    body = json_body
    assert body["data"]
    assert body["pagination"]
    assert_equal 1, body["pagination"]["page"]
    assert_equal 10, body["pagination"]["limit"]
    assert body["data"].length >= 1
  end

  # ── Read (by id) ─────────────────────────────────────────────────────────────

  test "GET /api/notes/:id — deve retornar nota por ID" do
    get_authed "/api/notes/#{@@note_id}", @@token

    assert_equal 200, last_response.status
    assert_equal @@note_id, json_body["id"]
  end

  test "GET /api/notes/:id — deve retornar 404 para ID inexistente" do
    get_authed "/api/notes/id-inexistente", @@token

    assert_equal 404, last_response.status
  end

  # ── Search ───────────────────────────────────────────────────────────────────

  test "GET /api/notes?search= — deve buscar notas por texto" do
    get_authed "/api/notes?search=Conteúdo", @@token

    assert_equal 200, last_response.status
    body = json_body
    assert body["data"].length >= 1
  end

  # ── Filter by tag ────────────────────────────────────────────────────────────

  test "GET /api/notes?tag= — deve filtrar por tag" do
    get_authed "/api/notes?tag=estudo", @@token

    assert_equal 200, last_response.status
    body = json_body
    assert body["data"].all? { |n| n["tags"].include?("estudo") }
  end

  # ── Update ───────────────────────────────────────────────────────────────────

  test "PUT /api/notes/:id — deve atualizar nota" do
    put_authed_json "/api/notes/#{@@note_id}", {
      title: "Título atualizado",
      content: "Conteúdo atualizado",
      tags: ["estudo", "ruby"]
    }, @@token

    assert_equal 200, last_response.status
    body = json_body
    assert_equal "Título atualizado", body["title"]
    assert body["tags"].include?("ruby")
    assert body["createdAt"]
    assert body["updatedAt"]
  end

  test "PUT /api/notes/:id — deve retornar 404 para nota inexistente" do
    put_authed_json "/api/notes/id-fake", {
      title: "X",
      content: "Y"
    }, @@token

    assert_equal 404, last_response.status
  end

  # ── Delete ───────────────────────────────────────────────────────────────────

  test "DELETE /api/notes/:id — deve remover nota" do
    delete_authed "/api/notes/#{@@note_id}", @@token

    assert_equal 204, last_response.status
  end

  test "DELETE /api/notes/:id — deve retornar 404 após remoção" do
    delete_authed "/api/notes/#{@@note_id}", @@token

    assert_equal 404, last_response.status
  end

  # ── Sem autenticação ─────────────────────────────────────────────────────────

  test "GET /api/notes — deve rejeitar requisição sem token" do
    get "/api/notes"

    assert_equal 401, last_response.status
  end
end
