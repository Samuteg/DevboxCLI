# frozen_string_literal: true

require_relative "test_helper"

class AuthTest < AppTest
  # Usuário compartilhado entre os testes
  @@user_email = "auth-test-#{Time.now.to_i}-#{rand(1000)}@email.com"
  @@user_password = "123456"
  @@user_name = "Teste Autenticação"

  @@access_token = nil
  @@refresh_token = nil

  # ─── Register ─────────────────────────────────────────────────────────────────

  test "POST /api/auth/register — deve cadastrar um novo usuário" do
    post_json "/api/auth/register", {
      name: @@user_name,
      email: @@user_email,
      password: @@user_password
    }

    assert_equal 201, last_response.status
    body = json_body
    assert body["id"]
    assert_equal @@user_name, body["name"]
    assert_equal @@user_email, body["email"]
    refute body.key?("password"), "não deve expor a senha"
  end

  test "POST /api/auth/register — deve rejeitar e-mail duplicado" do
    post_json "/api/auth/register", {
      name: @@user_name,
      email: @@user_email,
      password: @@user_password
    }

    assert_equal 409, last_response.status
    assert_equal "E-mail já cadastrado.", json_body["message"]
  end

  test "POST /api/auth/register — deve rejeitar dados inválidos" do
    post_json "/api/auth/register", {
      name: "",
      email: "invalido",
      password: "12"
    }

    assert_equal 400, last_response.status
    body = json_body
    assert body["errors"]
  end

  # ─── Login ───────────────────────────────────────────────────────────────────

  test "POST /api/auth/login — deve autenticar e retornar tokens" do
    post_json "/api/auth/login", {
      email: @@user_email,
      password: @@user_password
    }

    assert_equal 200, last_response.status
    body = json_body
    assert body["accessToken"]
    assert body["refreshToken"]
    assert_equal @@user_email, body["user"]["email"]

    @@access_token = body["accessToken"]
    @@refresh_token = body["refreshToken"]
  end

  test "POST /api/auth/login — deve rejeitar credenciais inválidas" do
    post_json "/api/auth/login", {
      email: @@user_email,
      password: "senha_errada"
    }

    assert_equal 401, last_response.status
  end

  # ─── Me ──────────────────────────────────────────────────────────────────────

  test "GET /api/auth/me — deve retornar dados do usuário autenticado" do
    get_authed "/api/auth/me", @@access_token

    assert_equal 200, last_response.status
    body = json_body
    assert_equal @@user_email, body["email"]
    assert_equal @@user_name, body["name"]
  end

  test "GET /api/auth/me — deve rejeitar requisição sem token" do
    get "/api/auth/me"

    assert_equal 401, last_response.status
  end

  # ─── Refresh ─────────────────────────────────────────────────────────────────

  test "POST /api/auth/refresh — deve renovar o access token" do
    post_json "/api/auth/refresh", {
      refreshToken: @@refresh_token
    }

    assert_equal 200, last_response.status
    body = json_body
    assert body["accessToken"]
    assert body["refreshToken"]
    refute_equal @@refresh_token, body["refreshToken"] # rotação

    # Atualiza para os próximos testes
    @@access_token = body["accessToken"]
    @@refresh_token = body["refreshToken"]
  end

  test "POST /api/auth/refresh — deve rejeitar refresh token inválido" do
    post_json "/api/auth/refresh", {
      refreshToken: "00000000-0000-0000-0000-000000000000"
    }

    assert_equal 401, last_response.status
  end

  # ─── Logout ──────────────────────────────────────────────────────────────────

  test "POST /api/auth/logout — deve revogar refresh tokens" do
    post_authed_json "/api/auth/logout", {}, @@access_token

    assert_equal 200, last_response.status
    assert_equal "Logout realizado com sucesso.", json_body["message"]
  end

  test "POST /api/auth/refresh — deve rejeitar refresh após logout" do
    post_json "/api/auth/refresh", {
      refreshToken: @@refresh_token
    }

    assert_equal 401, last_response.status
  end
end
