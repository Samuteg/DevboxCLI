# frozen_string_literal: true

require "jwt"
require "digest"
require "securerandom"

# Helpers de autenticação JWT.
#
# Fornece métodos para verificar tokens, gerar access/refresh tokens
# e extrair o usuário corrente das requisições autenticadas.
#
# Uso nas rotas:
#   authenticate!  # before filter que exige JWT válido
#   current_user   # retorna o usuário autenticado
module AuthHelpers
  # Constantes de tempo (em segundos)
  REFRESH_TOKEN_EXPIRY = 30 * 24 * 60 * 60 # 30 dias

  # ── Autenticação ──────────────────────────────────────────────────────────

  # Middleware/helper que verifica o token JWT no header Authorization.
  # Interrompe a requisição com 401 se o token for inválido ou expirado.
  def authenticate!
    auth_header = request.env["HTTP_AUTHORIZATION"]
    unless auth_header&.start_with?("Bearer ")
      halt 401, { message: "Token inválido ou não fornecido." }.to_json
    end

    token = auth_header.split(" ").last

    begin
      decoded = JWT.decode(token, settings.jwt_secret, true, algorithm: "HS256")
      payload = decoded.first
      @current_user = Db.find_user_by_id(payload["id"])
      halt 401, { message: "Usuário não encontrado." }.to_json unless @current_user
    rescue JWT::ExpiredSignature
      halt 401, { message: "Token expirado." }.to_json
    rescue JWT::DecodeError
      halt 401, { message: "Token inválido ou não fornecido." }.to_json
    end
  end

  # Retorna o usuário autenticado na requisição atual.
  # Deve ser chamado após authenticate!.
  def current_user
    @current_user
  end

  # ── Geração de Tokens ─────────────────────────────────────────────────────

  # Gera um access token JWT para o usuário.
  # Usa a configuração JWT_EXPIRES_IN (ex: "7d", "1h", "15m").
  def generate_access_token(user)
    exp_seconds = parse_duration(settings.jwt_expires_in)
    payload = {
      id: user["id"],
      name: user["name"],
      email: user["email"],
      exp: Time.now.to_i + exp_seconds
    }
    JWT.encode(payload, settings.jwt_secret, "HS256")
  end

  # Gera um refresh token (UUID v4 aleatório).
  def generate_refresh_token
    SecureRandom.uuid
  end

  # Retorna o hash SHA-256 de um token (para armazenamento seguro).
  def hash_token(token)
    Digest::SHA256.hexdigest(token)
  end

  # ── Utilitários ───────────────────────────────────────────────────────────

  # Converte uma string de duração como "7d", "1h", "30m" para segundos.
  def parse_duration(duration)
    case duration.to_s
    when /^(\d+)d$/ then Regexp.last_match(1).to_i * 86_400
    when /^(\d+)h$/ then Regexp.last_match(1).to_i * 3_600
    when /^(\d+)m$/ then Regexp.last_match(1).to_i * 60
    when /^(\d+)s$/ then Regexp.last_match(1).to_i
    else 7 * 86_400 # 7 dias (padrão)
    end
  end
end
