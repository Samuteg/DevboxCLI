# frozen_string_literal: true

require "logger"
require "json"

# Configuração do logger com formato apropriado para cada ambiente.
#
# - Desenvolvimento: formato colorido e legível para o terminal
# - Produção: JSON estruturado para sistemas de log centralizado
#
# Exemplo de uso:
#   Logger.setup
module LoggerConfig
  LEVELS = {
    "debug" => Logger::DEBUG,
    "info"  => Logger::INFO,
    "warn"  => Logger::WARN,
    "error" => Logger::ERROR,
    "fatal" => Logger::FATAL
  }.freeze

  # Cria e retorna uma instância de Logger configurada para o ambiente atual.
  def self.build
    logger = Logger.new($stdout)
    logger.level = resolve_level
    logger.formatter = formatter
    logger
  end

  # Define o formatter com base no ambiente.
  def self.formatter
    if ENV["RACK_ENV"] == "production"
      proc do |severity, datetime, _progname, msg|
        JSON.generate(
          level: severity,
          timestamp: datetime.iso8601(3),
          message: msg
        ) + "\n"
      end
    else
      proc do |severity, datetime, _progname, msg|
        color = COLOR_MAP[severity] || "\e[0m"
        ts = datetime.strftime("%Y-%m-%d %H:%M:%S.%L")
        "#{color}[#{ts}] #{severity.rjust(5)}: #{msg}\e[0m\n"
      end
    end
  end

  COLOR_MAP = {
    "DEBUG" => "\e[36m", # cyan
    "INFO"  => "\e[32m", # green
    "WARN"  => "\e[33m", # yellow
    "ERROR" => "\e[31m", # red
    "FATAL" => "\e[35m"  # magenta
  }.freeze

  private_class_method :formatter, :COLOR_MAP

  def self.resolve_level
    env = ENV["LOG_LEVEL"] || (ENV["RACK_ENV"] == "production" ? "info" : "debug")
    LEVELS.fetch(env.downcase, Logger::DEBUG)
  end

  private_class_method :resolve_level
end
