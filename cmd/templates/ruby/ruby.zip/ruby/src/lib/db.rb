# frozen_string_literal: true

require "sqlite3"
require "json"
require "fileutils"

# Camada de banco de dados SQLite.
#
# Responsável por inicializar o banco, criar as tabelas e prover
# todas as operações CRUD para usuários, notas e refresh tokens.
#
# Uso:
#   Db.init
#   user = Db.find_user_by_email("email@exemplo.com")
module Db
  DEFAULT_DB_PATH = File.join(__dir__, "..", "..", "data", "notes.db").freeze

  class << self
    # Inicializa a conexão com o banco SQLite.
    # Para testes, defina ENV["DB_PATH"] = ":memory:".
    def init
      return if @initialized

      path = ENV["DB_PATH"] || DEFAULT_DB_PATH
      is_memory = path == ":memory:"

      FileUtils.mkdir_p(File.dirname(path)) unless is_memory

      @db = SQLite3::Database.new(path)
      @db.results_as_hash = true
      @db.execute("PRAGMA journal_mode=WAL") unless is_memory
      @db.execute("PRAGMA foreign_keys = ON")
      create_tables
      @initialized = true
    end

    # Reinicia o banco (fecha conexão atual e permite re-inicializar).
    # Usado em testes para isolar o banco entre suítes.
    def reset!
      @db&.close
      @db = nil
      @initialized = false
    end

    # ── Usuários ────────────────────────────────────────────────────────

    def create_user(id:, name:, email:, password:)
      execute(
        "INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)",
        [id, name, email, password]
      )
    end

    def find_user_by_email(email)
      query_one("SELECT * FROM users WHERE email = ?", [email])
    end

    def find_user_by_id(id)
      query_one("SELECT * FROM users WHERE id = ?", [id])
    end

    # ── Notas ───────────────────────────────────────────────────────────

    def create_note(id:, user_id:, title:, content:, tags: [])
      now = Time.now.utc.iso8601(3)
      execute(
        "INSERT INTO notes (id, user_id, title, content, tags, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [id, user_id, title, content, JSON.generate(tags), now, now]
      )
      { id: id, title: title, content: content, tags: tags || [], createdAt: now, updatedAt: now }
    end

    def list_notes(user_id:, search: nil, tag: nil, page: 1, limit: 10)
      conditions = ["user_id = ?"]
      params = [user_id]

      if search && !search.empty?
        conditions << "(title LIKE ? OR content LIKE ?)"
        like = "%#{search}%"
        params.concat([like, like])
      end

      if tag && !tag.empty?
        conditions << "tags LIKE ?"
        params << "%\"#{tag}\"%"
      end

      where = conditions.join(" AND ")
      offset = (page - 1) * limit

      rows = query_all(
        "SELECT * FROM notes WHERE #{where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
        params + [limit.to_i, offset.to_i]
      )

      count_row = query_one("SELECT COUNT(*) as total FROM notes WHERE #{where}", params)
      total = count_row ? count_row["total"].to_i : 0

      {
        data: rows.map { |r| note_from_row(r) },
        pagination: {
          page: page,
          limit: limit,
          total: total,
          totalPages: total.zero? ? 0 : (total.to_f / limit).ceil
        }
      }
    end

    def find_note_by_id(id, user_id)
      row = query_one("SELECT * FROM notes WHERE id = ? AND user_id = ?", [id, user_id])
      row ? note_from_row(row) : nil
    end

    def update_note(id:, user_id:, title:, content:, tags: [])
      now = Time.now.utc.iso8601(3)
      execute(
        "UPDATE notes SET title = ?, content = ?, tags = ?, updated_at = ? WHERE id = ? AND user_id = ?",
        [title, content, JSON.generate(tags), now, id, user_id]
      )
      find_note_by_id(id, user_id)
    end

    def delete_note(id, user_id)
      existing = find_note_by_id(id, user_id)
      return false unless existing

      execute("DELETE FROM notes WHERE id = ? AND user_id = ?", [id, user_id])
      true
    end

    # ── Refresh Tokens ──────────────────────────────────────────────────

    def save_refresh_token(id:, user_id:, token_hash:, expires_at:)
      execute(
        "INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at) VALUES (?, ?, ?, ?)",
        [id, user_id, token_hash, expires_at]
      )
    end

    def find_refresh_token(token_hash)
      query_one(
        "SELECT * FROM refresh_tokens WHERE token_hash = ? AND revoked = 0",
        [token_hash]
      )
    end

    def revoke_refresh_token(id)
      execute("UPDATE refresh_tokens SET revoked = 1 WHERE id = ?", [id])
    end

    def revoke_all_user_refresh_tokens(user_id)
      execute("UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ?", [user_id])
    end

    private

    # Retorna a conexão ativa com o banco.
    def db
      @db or raise "Banco não inicializado. Chame Db.init primeiro."
    end

    # Cria as tabelas caso não existam.
    def create_tables
      db.execute <<~SQL
        CREATE TABLE IF NOT EXISTS users (
          id         TEXT PRIMARY KEY,
          name       TEXT NOT NULL,
          email      TEXT NOT NULL UNIQUE,
          password   TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
      SQL

      db.execute <<~SQL
        CREATE TABLE IF NOT EXISTS notes (
          id         TEXT PRIMARY KEY,
          user_id    TEXT NOT NULL,
          title      TEXT NOT NULL,
          content    TEXT NOT NULL,
          tags       TEXT NOT NULL DEFAULT '[]',
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          updated_at TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
      SQL

      db.execute <<~SQL
        CREATE TABLE IF NOT EXISTS refresh_tokens (
          id          TEXT PRIMARY KEY,
          user_id     TEXT NOT NULL,
          token_hash  TEXT NOT NULL,
          expires_at  TEXT NOT NULL,
          revoked     INTEGER NOT NULL DEFAULT 0,
          created_at  TEXT NOT NULL DEFAULT (datetime('now')),
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
      SQL

      db.execute("CREATE INDEX IF NOT EXISTS idx_notes_user_id ON notes(user_id)")
      db.execute("CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user_id ON refresh_tokens(user_id)")
    end

    # Executa uma consulta que retorna múltiplas linhas.
    def query_all(sql, params = [])
      db.execute(sql, params)
    end

    # Executa uma consulta que retorna uma única linha.
    def query_one(sql, params = [])
      db.get_first_row(sql, params)
    end

    # Executa um comando de escrita (INSERT, UPDATE, DELETE).
    def execute(sql, params = [])
      db.execute(sql, params)
    end

    # Converte uma linha do banco para o formato de resposta da API.
    def note_from_row(row)
      {
        id: row["id"],
        title: row["title"],
        content: row["content"],
        tags: JSON.parse(row["tags"] || "[]"),
        createdAt: row["created_at"],
        updatedAt: row["updated_at"]
      }
    end
  end
end
