# ✍️ Notes CRUD API v2.0.0 — Ruby

API RESTful de notas com autenticação JWT, refresh token, tags, paginação, busca textual e documentação Swagger — em **Ruby** com **Sinatra**.

Este projeto é a versão Ruby dos templates [TypeScript](../ts/) e [JavaScript](../js/), mantendo as mesmas funcionalidades, estrutura e padrões de código.

## 📋 Índice

- [Funcionalidades](#-funcionalidades)
- [Tecnologias](#-tecnologias)
- [Pré-requisitos](#-pré-requisitos)
- [Instalação e execução](#-instalação-e-execução)
- [Variáveis de ambiente](#-variáveis-de-ambiente)
- [Scripts disponíveis](#-scripts-disponíveis)
- [Documentação Swagger](#-documentação-swagger)
- [Estrutura do projeto](#-estrutura-do-projeto)
- [Endpoints](#-endpoints)
  - [Autenticação](#-autenticação)
  - [Notas](#-notas)
- [Fluxo de uso](#-fluxo-de-uso)
- [Exemplo completo com cURL](#-exemplo-completo-com-curl)
- [Docker](#-docker)
- [Testes](#-testes)
- [Licença](#-licença)

## ✨ Funcionalidades

- ✅ Cadastro e autenticação de usuários (JWT + bcrypt)
- ✅ Refresh token com rotação (SHA-256)
- ✅ CRUD completo de notas
- ✅ Tags nas notas (array de strings)
- ✅ Paginação (page/limit)
- ✅ Busca textual no título e conteúdo
- ✅ Filtro por tag
- ✅ Rate limiting (100 req/min)
- ✅ Documentação Swagger UI em `/docs`
- ✅ CORS habilitado
- ✅ Logs coloridos em desenvolvimento / JSON em produção
- ✅ Testes automatizados com Minitest + Rack::Test
- ✅ Docker prontinho

## 🛠 Tecnologias

| Tecnologia     | Versão | Descrição                          |
| -------------- | ------ | ---------------------------------- |
| **Ruby**       | ≥ 3.1  | Linguagem                          |
| **Sinatra**    | 4.x    | Framework web                      |
| **Puma**       | 6.x    | Servidor HTTP                      |
| **SQLite3**    | 2.x    | Banco de dados                     |
| **JWT**        | 2.x    | Tokens JWT                         |
| **BCrypt**     | 3.x    | Hash de senhas                     |
| **Rack::Cors** | 2.x    | CORS                               |
| **Rack::Attack** | 6.x  | Rate limiting                      |
| **Minitest**   | 5.x    | Testes                             |
| **Rack::Test** | 2.x    | Testes HTTP                        |
| **Dotenv**     | 3.x    | Variáveis de ambiente              |

**Comparativo com as versões JS/TS:**

| Funcionalidade      | TypeScript / JavaScript   | Ruby                     |
| ------------------- | ------------------------- | ------------------------ |
| Framework           | Fastify                   | **Sinatra**              |
| Banco               | sql.js (SQLite WASM)      | **sqlite3** (nativo)     |
| Validação           | Zod                       | **Validação manual**     |
| Logger              | Pino                      | **Logger (stdlib)**      |
| Testes              | Vitest                    | **Minitest + Rack::Test**|
| UUID                | uuid                      | **SecureRandom (stdlib)**|
| Autenticação        | @fastify/jwt              | **jwt gem**              |

## 📋 Pré-requisitos

- Ruby ≥ 3.1
- Bundler (`gem install bundler`)
- SQLite3 (biblioteca C, já presente na maioria dos sistemas)

## 🚀 Instalação e execução

```bash
# 1. Clone o repositório e entre na pasta
cd templates/ruby

# 2. Instale as dependências
bundle install

# 3. Copie o arquivo de ambiente e ajuste se necessário
cp .env.example .env

# 4. Execute o servidor
ruby src/app.rb
```

O servidor iniciará em `http://localhost:3000`.

## 🔐 Variáveis de Ambiente

| Variável                      | Padrão            | Descrição                               |
| ----------------------------- | ----------------- | --------------------------------------- |
| `PORT`                        | `3000`            | Porta do servidor                       |
| `JWT_SECRET`                  | `fallback-secret` | Segredo para assinar os tokens JWT      |
| `JWT_EXPIRES_IN`              | `7d`              | Tempo de expiração do access token      |
| `REFRESH_TOKEN_EXPIRES_IN_DAYS` | `30`            | Dias de validade do refresh token       |
| `RACK_ENV`                    | `development`     | Ambiente (`development`, `production`)  |
| `LOG_LEVEL`                   | `debug` (dev) / `info` (prod) | Nível de log         |

## 📜 Scripts disponíveis

```bash
# Executar o servidor
ruby src/app.rb

# Executar em modo watch (requer rerun)
bundle exec rerun -- ruby src/app.rb

# Executar testes
ruby -I src/__tests__ src/__tests__/auth_test.rb
ruby -I src/__tests__ src/__tests__/notes_test.rb

# Executar todos os testes
rake test

# OU
ruby -e "Dir['src/__tests__/*_test.rb'].each { |f| require_relative f }"
```

## 📖 Documentação Swagger

Acesse `http://localhost:3000/docs` para visualizar a documentação interativa da API via Swagger UI.

A especificação OpenAPI também está disponível em `http://localhost:3000/api/openapi.json`.

## 📁 Estrutura do projeto

```
ruby/
├── src/
│   ├── app.rb               # Configuração principal e inicialização
│   ├── openapi.json          # Especificação OpenAPI 3.0
│   ├── lib/
│   │   ├── db.rb             # Camada de banco de dados (SQLite)
│   │   └── logger_config.rb  # Configuração de logger
│   ├── helpers/
│   │   └── auth_helpers.rb   # Helpers de autenticação JWT
│   ├── routes/
│   │   ├── auth.rb           # Rotas de autenticação
│   │   └── notes.rb          # Rotas do CRUD de notas
│   └── __tests__/
│       ├── test_helper.rb    # Configuração dos testes
│       ├── auth_test.rb      # Testes de autenticação
│       └── notes_test.rb     # Testes de notas
├── data/                     # Banco SQLite (criado automaticamente)
├── config.ru                 # Rack config (para deploy)
├── Gemfile                   # Dependências
├── Rakefile                  # Tarefas Rake
├── Dockerfile                # Imagem Docker
├── docker-compose.yml        # Docker Compose
└── .env.example              # Exemplo de variáveis de ambiente
```

## 📡 Endpoints

### 🔑 Autenticação

#### `POST /api/auth/register`

Cadastrar um novo usuário.

**Request:**
```json
{
  "name": "João Silva",
  "email": "joao@email.com",
  "password": "123456"
}
```

**Response 201:**
```json
{
  "id": "uuid",
  "name": "João Silva",
  "email": "joao@email.com"
}
```

**Erros:** `400` (validação), `409` (e-mail duplicado)

---

#### `POST /api/auth/login`

Autenticar e obter access token + refresh token.

**Request:**
```json
{
  "email": "joao@email.com",
  "password": "123456"
}
```

**Response 200:**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
  "refreshToken": "uuid",
  "user": {
    "id": "uuid",
    "name": "João Silva",
    "email": "joao@email.com"
  }
}
```

**Erros:** `400` (validação), `401` (credenciais inválidas)

---

#### `POST /api/auth/refresh`

Renovar access token usando refresh token.

**Request:**
```json
{
  "refreshToken": "uuid"
}
```

**Response 200:**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
  "refreshToken": "novo-uuid"
}
```

> ⚠️ O refresh token é **rotacionado** a cada uso — o token anterior é revogado.

**Erros:** `401` (inválido, expirado ou já utilizado)

---

#### `POST /api/auth/logout`

Revogar todos os refresh tokens do usuário.

**Headers:** `Authorization: Bearer <accessToken>`

**Response 200:**
```json
{
  "message": "Logout realizado com sucesso."
}
```

---

#### `GET /api/auth/me`

Retorna os dados do usuário autenticado.

**Headers:** `Authorization: Bearer <accessToken>`

**Response 200:**
```json
{
  "id": "uuid",
  "name": "João Silva",
  "email": "joao@email.com"
}
```

---

### 📝 Notas

Todas as rotas de notas exigem `Authorization: Bearer <accessToken>`.

#### `POST /api/notes`

Criar uma nova nota.

**Request:**
```json
{
  "title": "Minha nota",
  "content": "Conteúdo interessante",
  "tags": ["estudo", "ruby"]
}
```

**Response 201:**
```json
{
  "id": "uuid",
  "title": "Minha nota",
  "content": "Conteúdo interessante",
  "tags": ["estudo", "ruby"],
  "createdAt": "2025-01-01T00:00:00Z",
  "updatedAt": "2025-01-01T00:00:00Z"
}
```

---

#### `GET /api/notes`

Listar notas com paginação, busca textual e filtro por tag.

**Query params:**

| Parâmetro | Tipo    | Padrão | Descrição                          |
| --------- | ------- | ------ | ---------------------------------- |
| `page`    | integer | `1`    | Número da página                   |
| `limit`   | integer | `10`   | Itens por página (max 100)         |
| `search`  | string  | —      | Busca no título e conteúdo         |
| `tag`     | string  | —      | Filtrar por tag                    |

**Response 200:**
```json
{
  "data": [
    {
      "id": "uuid",
      "title": "Minha nota",
      "content": "Conteúdo interessante",
      "tags": ["estudo", "ruby"],
      "createdAt": "2025-01-01T00:00:00Z",
      "updatedAt": "2025-01-01T00:00:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "totalPages": 1
  }
}
```

---

#### `GET /api/notes/:id`

Obter uma nota específica pelo ID.

**Response 200:** Nota completa (mesmo schema do POST)

**Response 404:** `{ "message": "Nota não encontrada." }`

---

#### `PUT /api/notes/:id`

Atualizar uma nota existente.

**Request:** (mesmo schema do POST)
```json
{
  "title": "Título atualizado",
  "content": "Novo conteúdo",
  "tags": ["estudo", "sinatra"]
}
```

**Response 200:** Nota atualizada

**Response 404:** `{ "message": "Nota não encontrada." }`

---

#### `DELETE /api/notes/:id`

Remover uma nota.

**Response:** `204 No Content`

**Response 404:** `{ "message": "Nota não encontrada." }`

## 🔄 Fluxo de uso

```mermaid
sequenceDiagram
    participant C as Cliente
    participant API

    C->>API: POST /api/auth/register
    API-->>C: 201 { id, name, email }

    C->>API: POST /api/auth/login
    API-->>C: 200 { accessToken, refreshToken, user }

    C->>API: POST /api/notes (Bearer accessToken)
    API-->>C: 201 { id, title, content, tags, ... }

    C->>API: GET /api/notes (Bearer accessToken)
    API-->>C: 200 { data[], pagination }

    C->>API: GET /api/notes/:id (Bearer accessToken)
    API-->>C: 200 { id, title, content, ... }

    C->>API: PUT /api/notes/:id (Bearer accessToken)
    API-->>C: 200 { id, title, content, ... }

    C->>API: DELETE /api/notes/:id (Bearer accessToken)
    API-->>C: 204

    Note over C,API: Access token expirou

    C->>API: POST /api/auth/refresh { refreshToken }
    API-->>C: 200 { accessToken, refreshToken }

    C->>API: POST /api/auth/logout (Bearer accessToken)
    API-->>C: 200 { message }
```

## 🧪 Exemplo completo com cURL

```bash
# ── 1. Registrar ─────────────────────────────────────────────────────
curl -s -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"João","email":"joao@email.com","password":"123456"}'

# ── 2. Login ─────────────────────────────────────────────────────────
LOGIN=$(curl -s -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"joao@email.com","password":"123456"}')

TOKEN=$(echo "$LOGIN" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["accessToken"]')
REFRESH=$(echo "$LOGIN" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["refreshToken"]')

echo "Token: $TOKEN"

# ── 3. Criar nota ────────────────────────────────────────────────────
NOTE=$(curl -s -X POST http://localhost:3000/api/notes \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"title":"Minha nota","content":"Estudando Ruby","tags":["estudo","ruby"]}')

NOTE_ID=$(echo "$NOTE" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
echo "Nota ID: $NOTE_ID"

# ── 4. Listar notas ──────────────────────────────────────────────────
curl -s http://localhost:3000/api/notes \
  -H "Authorization: Bearer $TOKEN" | ruby -rjson -e 'puts JSON.pretty_generate(JSON.parse(STDIN.read))'

# ── 5. Buscar notas ──────────────────────────────────────────────────
curl -s "http://localhost:3000/api/notes?search=Ruby" \
  -H "Authorization: Bearer $TOKEN" | ruby -rjson -e 'puts JSON.pretty_generate(JSON.parse(STDIN.read))'

# ── 6. Atualizar nota ────────────────────────────────────────────────
curl -s -X PUT "http://localhost:3000/api/notes/$NOTE_ID" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"title":"Título atualizado","content":"Aprendendo Sinatra","tags":["estudo","sinatra"]}'

# ── 7. Refresh token ─────────────────────────────────────────────────
curl -s -X POST http://localhost:3000/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d "{\"refreshToken\":\"$REFRESH\"}"

# ── 8. Logout ────────────────────────────────────────────────────────
curl -s -X POST http://localhost:3000/api/auth/logout \
  -H "Authorization: Bearer $TOKEN"

# ── 9. Ver dados do usuário ──────────────────────────────────────────
curl -s http://localhost:3000/api/auth/me \
  -H "Authorization: Bearer $TOKEN"

# ── 10. Deletar nota ─────────────────────────────────────────────────
curl -s -o /dev/null -w "%{http_code}" -X DELETE "http://localhost:3000/api/notes/$NOTE_ID" \
  -H "Authorization: Bearer $TOKEN"
```

## 🐳 Docker

### Pré-requisitos

- Docker e Docker Compose instalados

### Build e execução

```bash
# Build da imagem
docker compose build

# Executar o container
docker compose up -d

# Ver logs
docker compose logs -f

# Parar o container
docker compose down
```

A API estará disponível em `http://localhost:3000`.

O banco SQLite é persistido em um volume Docker (`notes_data`), garantindo que os dados não sejam perdidos ao reiniciar o container.

## 🧪 Testes

Os testes utilizam **Minitest** + **Rack::Test** para realizar requisições HTTP simuladas sem a necessidade de um servidor rodando.

### Estrutura dos testes

```
src/__tests__/
├── test_helper.rb   # Configuração e classe base
├── auth_test.rb     # Testes de autenticação (8 testes)
└── notes_test.rb    # Testes do CRUD de notas (12+ testes)
```

### Executar

```bash
# Executar todos os testes
ruby -e "Dir['src/__tests__/*_test.rb'].each { |f| require_relative f }"

# Executar teste específico
ruby -I src/__tests__ src/__tests__/auth_test.rb
ruby -I src/__tests__ src/__tests__/notes_test.rb
```

Testes implementados:

- **Autenticação (8 testes):**
  - Registro com sucesso
  - E-mail duplicado
  - Dados inválidos
  - Login com sucesso
  - Credenciais inválidas
  - Dados do usuário (me)
  - Refresh token
  - Logout

- **Notas (12+ testes):**
  - Criar nota com tags
  - Criar nota sem título
  - Listar com paginação
  - Obter por ID
  - Nota inexistente (404)
  - Busca textual
  - Filtro por tag
  - Atualizar nota
  - Atualizar inexistente
  - Deletar nota
  - Deletar inexistente
  - Sem autenticação

## 📄 Licença

MIT
