# frozen_string_literal: true

require_relative "src/app"

run NotesApp
