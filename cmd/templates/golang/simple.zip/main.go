package main

import "fmt"

func main() {
	fmt.Println("🚀 Projeto {{PROJECT_NAME}} rodando!")
}
