package handlers

import (
	"gin/config"
	"gin/models"
	"net/http"

	"github.com/gin-gonic/gin"
)

// GetNotes godoc
// @Summary      Listar todas as notas
// @Description  Retorna todas as notas do usuário autenticado
// @Tags         notes
// @Produce      json
// @Security     BearerAuth
// @Success      200  {object}  map[string][]models.Note
// @Failure      401  {object}  map[string]string
// @Router       /notes [get]
func GetNotes(c *gin.Context) {
	userID := c.GetUint("user_id")

	var notes []models.Note
	config.DB.Where("user_id = ?", userID).Find(&notes)

	c.JSON(http.StatusOK, gin.H{"notes": notes})
}

// GetNote godoc
// @Summary      Obter uma nota por ID
// @Description  Retorna uma nota específica do usuário autenticado
// @Tags         notes
// @Produce      json
// @Security     BearerAuth
// @Param        id   path      string  true  "ID da nota"
// @Success      200  {object}  map[string]models.Note
// @Failure      401  {object}  map[string]string
// @Failure      404  {object}  map[string]string
// @Router       /notes/{id} [get]
func GetNote(c *gin.Context) {
	userID := c.GetUint("user_id")
	noteID := c.Param("id")

	var note models.Note
	if err := config.DB.Where("id = ? AND user_id = ?", noteID, userID).First(&note).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "note not found"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"note": note})
}

// CreateNote godoc
// @Summary      Criar uma nova nota
// @Description  Cria uma nota para o usuário autenticado
// @Tags         notes
// @Accept       json
// @Produce      json
// @Security     BearerAuth
// @Param        input  body      models.Note  true  "Dados da nota"
// @Success      200    {object}  map[string]models.Note
// @Failure      400    {object}  map[string]string
// @Failure      401    {object}  map[string]string
// @Failure      500    {object}  map[string]string
// @Router       /notes [post]
func CreateNote(c *gin.Context) {
	userID := c.GetUint("user_id")

	var input models.Note
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	input.UserID = userID

	if err := config.DB.Create(&input).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to create note"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"note": input})
}

// UpdateNote godoc
// @Summary      Atualizar uma nota
// @Description  Atualiza uma nota existente do usuário autenticado
// @Tags         notes
// @Accept       json
// @Produce      json
// @Security     BearerAuth
// @Param        id    path      string      true  "ID da nota"
// @Param        input body      models.Note  true  "Dados atualizados da nota"
// @Success      200   {object}  map[string]models.Note
// @Failure      400   {object}  map[string]string
// @Failure      401   {object}  map[string]string
// @Failure      404   {object}  map[string]string
// @Router       /notes/{id} [put]
func UpdateNote(c *gin.Context) {
	userID := c.GetUint("user_id")
	noteID := c.Param("id")

	var note models.Note
	if err := config.DB.Where("id = ? AND user_id = ?", noteID, userID).First(&note).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "note not found"})
		return
	}

	var input models.Note
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	note.Title = input.Title
	note.Content = input.Content
	config.DB.Save(&note)

	c.JSON(http.StatusOK, gin.H{"note": note})
}

// DeleteNote godoc
// @Summary      Deletar uma nota
// @Description  Deleta uma nota existente do usuário autenticado
// @Tags         notes
// @Produce      json
// @Security     BearerAuth
// @Param        id   path      string  true  "ID da nota"
// @Success      200  {object}  map[string]string
// @Failure      401  {object}  map[string]string
// @Failure      404  {object}  map[string]string
// @Router       /notes/{id} [delete]
func DeleteNote(c *gin.Context) {
	userID := c.GetUint("user_id")
	noteID := c.Param("id")

	var note models.Note
	if err := config.DB.Where("id = ? AND user_id = ?", noteID, userID).First(&note).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "note not found"})
		return
	}

	config.DB.Delete(&note)

	c.JSON(http.StatusOK, gin.H{"message": "note deleted successfully"})
}
