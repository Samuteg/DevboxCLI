# Notes API — CRUD de Notas com Login

API RESTful para gerenciamento de notas pessoais com autenticação JWT, documentada com Swagger.

---

## Funcionalidades

- **Registro de usuários** com validação de email e senha hasheada com bcrypt
- **Login** com retorno de token JWT (validade de 24h)
- **CRUD completo de notas** — cada usuário só acessa suas próprias notas
- **Documentação Swagger** interativa via `/swagger/index.html`
- **Banco SQLite** serverless — sem necessidade de servidor externo

## Stack

| Tecnologia | Versão | Descrição |
|---|---|---|
| [Go](https://go.dev/) | 1.26+ | Linguagem |
| [Gin](https://github.com/gin-gonic/gin) | v1.10.0 | Framework HTTP |
| [GORM](https://gorm.io/) | v1.25.12 | ORM |
| [SQLite](https://www.sqlite.org/) | via `go-sqlite3` | Banco de dados |
| [golang-jwt](https://github.com/golang-jwt/jwt) | v5.2.1 | Autenticação JWT |
| [bcrypt](https://pkg.go.dev/golang.org/x/crypto) | v0.36.0 | Hash de senhas |
| [swaggo](https://github.com/swaggo/swag) | v1.16.6 | Documentação Swagger |

---

## Estrutura do Projeto

```
gin/
├── main.go                   # Ponto de entrada — inicializa DB, Swagger e rotas
├── go.mod                    # Dependências do módulo
├── go.sum                    # Checksums das dependências
├── notes.db                  # Banco SQLite (gerado automaticamente)
│
├── config/
│   └── database.go           # Conexão com SQLite e auto-migração das tabelas
│
├── models/
│   ├── user.go               # Modelo User (Name, Email, Password)
│   └── note.go               # Modelo Note (Title, Content, UserID → FK User)
│
├── handlers/
│   ├── auth.go               # Handlers Register e Login
│   └── notes.go              # Handlers GetNotes, GetNote, CreateNote, UpdateNote, DeleteNote
│
├── middleware/
│   └── auth.go               # Middleware JWT — valida token Bearer e injeta user_id no contexto
│
├── routes/
│   └── routes.go             # Organização de rotas públicas e protegidas
│
├── docs/
│   ├── docs.go               # Spec Swagger gerada pelo swag
│   ├── swagger.json          # Spec OpenAPI em JSON
│   └── swagger.yaml          # Spec OpenAPI em YAML
│
└── README.md                 # Este arquivo
```

---

## Pré-requisitos

- [Go](https://go.dev/dl/) 1.26 ou superior
- C compilador (necessário para o CGo do SQLite — `gcc` no Linux, `xcode-select --install` no macOS)

## Instalação e Execução

```bash
# Clonar/entrar no diretório
cd gin

# Instalar dependências
go mod tidy

# Rodar o servidor
go run main.go
```

O servidor inicia em `http://localhost:8080`. Na primeira execução, o banco `notes.db` é criado automaticamente com as tabelas `users` e `notes`.

---

## Arquitetura

```mermaid
flowchart TD
    Client[Client / curl / Swagger UI] --> Router[Gin Router :8080]
    Router --> Swagger["/swagger/*any<br/>Swagger UI"]
    Router --> API["/api/*"]
    API --> Public{{Rotas Públicas}}
    API --> Protected{{Rotas Protegidas}}
    Public --> Register["POST /register"]
    Public --> Login["POST /login"]
    Protected --> Middleware["Middleware JWT<br/>valida token → injeta user_id"]
    Middleware --> Notes["CRUD /notes"]
    Notes --> DB[(SQLite — notes.db)]
```

**Fluxo de autenticação:**

```mermaid
sequenceDiagram
    participant C as Client
    participant S as Server
    participant DB as SQLite

    C->>S: POST /api/register {name, email, password}
    S->>DB: INSERT INTO users (password hasheada com bcrypt)
    S-->>C: 200 {"message": "registration successful"}

    C->>S: POST /api/login {email, password}
    S->>DB: SELECT user WHERE email = ?
    S->>S: bcrypt.CompareHashAndPassword
    S-->>C: 200 {"token": "eyJhbG..."}
    
    C->>S: GET /api/notes (Authorization: Bearer token)
    S->>S: Middleware valida JWT, extrai user_id
    S->>DB: SELECT * FROM notes WHERE user_id = ?
    S-->>C: 200 {"notes": [...]}
```

---

## Modelos de Dados

### User

| Campo | Tipo | Constraints | Observação |
|---|---|---|---|
| `id` | uint | PK, auto-increment | Gerado pelo GORM |
| `created_at` | timestamp | | Gerado pelo GORM |
| `updated_at` | timestamp | | Gerado pelo GORM |
| `deleted_at` | timestamp | | Soft delete (GORM) |
| `name` | string | obrigatório | |
| `email` | string | obrigatório, único, email válido | |
| `password` | string | obrigatório, min 6 chars | Hasheada com bcrypt; omitida do JSON (`json:"-"`) |

### Note

| Campo | Tipo | Constraints | Observação |
|---|---|---|---|
| `id` | uint | PK, auto-increment | Gerado pelo GORM |
| `created_at` | timestamp | | Gerado pelo GORM |
| `updated_at` | timestamp | | Gerado pelo GORM |
| `deleted_at` | timestamp | | Soft delete (GORM) |
| `title` | string | obrigatório | |
| `content` | string | obrigatório | |
| `user_id` | uint | FK → User | Definida pelo JWT, não pelo client |

---

## Endpoints

### Autenticação — Rotas Públicas

#### `POST /api/register`

Registra um novo usuário.

**Request Body:**

```json
{
  "name": "João",
  "email": "joao@email.com",
  "password": "123456"
}
```

| Campo | Tipo | Regras |
|---|---|---|
| `name` | string | obrigatório |
| `email` | string | obrigatório, formato email |
| `password` | string | obrigatório, mínimo 6 caracteres |

**Respostas:**

| Código | Body | Descrição |
|---|---|---|
| `200` | `{"message": "registration successful"}` | Sucesso |
| `400` | `{"error": "email already exists"}` | Email duplicado ou validação |
| `500` | `{"error": "failed to hash password"}` | Erro interno |

---

#### `POST /api/login`

Autentica o usuário e retorna um token JWT.

**Request Body:**

```json
{
  "email": "joao@email.com",
  "password": "123456"
}
```

**Respostas:**

| Código | Body | Descrição |
|---|---|---|
| `200` | `{"token": "eyJhbGciOiJIUzI1NiIs..."}` | Token JWT (validade 24h) |
| `400` | `{"error": "..."}` | Validação do body |
| `401` | `{"error": "invalid email or password"}` | Credenciais inválidas |

---

### Notas — Rotas Protegidas

> Todas as rotas abaixo exigem o header `Authorization: Bearer <token>`.

#### `GET /api/notes`

Lista todas as notas do usuário autenticado.

**Respostas:**

| Código | Body | Descrição |
|---|---|---|
| `200` | `{"notes": [{ "id": 1, "title": "...", "content": "...", ... }]}` | Lista de notas |
| `401` | `{"error": "..."}` | Token ausente/inválido |

---

#### `GET /api/notes/:id`

Retorna uma nota específica pelo ID.

| Parâmetro | Tipo | Local | Descrição |
|---|---|---|---|
| `id` | uint | path | ID da nota |

**Respostas:**

| Código | Body | Descrição |
|---|---|---|
| `200` | `{"note": { "id": 1, ... }}` | Nota encontrada |
| `401` | `{"error": "..."}` | Token ausente/inválido |
| `404` | `{"error": "note not found"}` | Nota não encontrada ou pertence a outro usuário |

---

#### `POST /api/notes`

Cria uma nova nota.

**Request Body:**

```json
{
  "title": "Minha Nota",
  "content": "Conteúdo da nota"
}
```

| Campo | Tipo | Regras |
|---|---|---|
| `title` | string | obrigatório |
| `content` | string | obrigatório |

> O `user_id` é extraído automaticamente do token JWT.

**Respostas:**

| Código | Body | Descrição |
|---|---|---|
| `200` | `{"note": { "id": 1, "title": "...", ... }}` | Nota criada |
| `400` | `{"error": "..."}` | Validação do body |
| `401` | `{"error": "..."}` | Token ausente/inválido |
| `500` | `{"error": "failed to create note"}` | Erro ao salvar no banco |

---

#### `PUT /api/notes/:id`

Atualiza uma nota existente.

| Parâmetro | Tipo | Local | Descrição |
|---|---|---|---|
| `id` | uint | path | ID da nota |

**Request Body:**

```json
{
  "title": "Título Atualizado",
  "content": "Conteúdo atualizado"
}
```

**Respostas:**

| Código | Body | Descrição |
|---|---|---|
| `200` | `{"note": { "id": 1, "title": "...", ... }}` | Nota atualizada |
| `400` | `{"error": "..."}` | Validação do body |
| `401` | `{"error": "..."}` | Token ausente/inválido |
| `404` | `{"error": "note not found"}` | Nota não encontrada |

---

#### `DELETE /api/notes/:id`

Deleta uma nota existente (soft delete via GORM).

| Parâmetro | Tipo | Local | Descrição |
|---|---|---|---|
| `id` | uint | path | ID da nota |

**Respostas:**

| Código | Body | Descrição |
|---|---|---|
| `200` | `{"message": "note deleted successfully"}` | Nota deletada |
| `401` | `{"error": "..."}` | Token ausente/inválido |
| `404` | `{"error": "note not found"}` | Nota não encontrada |

---

## Swagger

A documentação interativa da API está disponível em:

**http://localhost:8080/swagger/index.html**

### Regenerar documentação

Após alterar anotações nos handlers:

```bash
~/go/bin/swag init --parseDependency --parseInternal
```

### Estrutura das anotações

Cada handler possui anotações no formato `@` sobre a função:

```go
// GetNote godoc
// @Summary      Obter uma nota por ID
// @Description  Retorna uma nota específica do usuário autenticado
// @Tags         notes
// @Produce      json
// @Security     BearerAuth
// @Param        id   path      string  true  "ID da nota"
// @Success      200  {object}  map[string]models.Note
// @Failure      401  {object}  map[string]string
// @Failure      404  {object}  map[string]string
// @Router       /notes/{id} [get]
```

Na UI do Swagger, use o botão **Authorize** para inserir o token JWT (formato `Bearer <token>`) e testar as rotas protegidas.

---

## Autenticação JWT

### Como funciona

1. O client faz `POST /api/login` com email e senha
2. O servidor valida as credenciais com bcrypt e retorna um token JWT
3. O client envia o token em todas as requisições protegidas via header `Authorization: Bearer <token>`
4. O middleware `AuthRequired` valida o token, extrai `user_id` e `email`, e os injeta no contexto do Gin
5. Os handlers usam `c.GetUint("user_id")` para filtrar dados do usuário

### Detalhes do token

| Campo | Valor |
|---|---|
| Algoritmo | HS256 |
| Claims | `user_id`, `email`, `exp`, `iat` |
| Validade | 24 horas |
| Chave secreta | `my_secret_key` (definida em `middleware/auth.go` — trocar em produção!) |

---

## Exemplos com curl

### 1. Registrar usuário

```bash
curl -X POST http://localhost:8080/api/register \
  -H "Content-Type: application/json" \
  -d '{"name":"João","email":"joao@email.com","password":"123456"}'
```

```json
{"message":"registration successful"}
```

### 2. Login

```bash
curl -X POST http://localhost:8080/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"joao@email.com","password":"123456"}'
```

```json
{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."}
```

> Salve o token retornado para usar nas requisições abaixo.

### 3. Criar nota

```bash
curl -X POST http://localhost:8080/api/notes \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SEU_TOKEN" \
  -d '{"title":"Compras do mercado","content":"Leite, ovos, pão, café"}'
```

```json
{"note":{"ID":1,"CreatedAt":"2025-01-15T10:30:00Z","UpdatedAt":"2025-01-15T10:30:00Z","DeletedAt":null,"title":"Compras do mercado","content":"Leite, ovos, pão, café","user_id":1}}
```

### 4. Listar todas as notas

```bash
curl http://localhost:8080/api/notes \
  -H "Authorization: Bearer SEU_TOKEN"
```

```json
{"notes":[{"ID":1,"title":"Compras do mercado","content":"Leite, ovos, pão, café","user_id":1}]}
```

### 5. Obter nota por ID

```bash
curl http://localhost:8080/api/notes/1 \
  -H "Authorization: Bearer SEU_TOKEN"
```

```json
{"note":{"ID":1,"title":"Compras do mercado","content":"Leite, ovos, pão, café","user_id":1}}
```

### 6. Atualizar nota

```bash
curl -X PUT http://localhost:8080/api/notes/1 \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SEU_TOKEN" \
  -d '{"title":"Compras do mercado (atualizado)","content":"Leite, ovos, pão, café, frutas"}'
```

```json
{"note":{"ID":1,"title":"Compras do mercado (atualizado)","content":"Leite, ovos, pão, café, frutas","user_id":1}}
```

### 7. Deletar nota

```bash
curl -X DELETE http://localhost:8080/api/notes/1 \
  -H "Authorization: Bearer SEU_TOKEN"
```

```json
{"message":"note deleted successfully"}
```

---

## Banco de Dados

- **Engine:** SQLite (arquivo `notes.db` na raiz do projeto)
- **ORM:** GORM com auto-migração — tabelas são criadas/alteradas automaticamente ao iniciar
- **Soft delete:** `DeletedAt` no `gorm.Model` — registros são marcados como deletados, não removidos fisicamente
- **Sem configuração externa:** ideal para desenvolvimento e prototipagem. Para produção, considerar trocar para PostgreSQL ou MySQL

---

## Segurança — Notas

- A chave secreta JWT (`my_secret_key`) está hardcoded — **trocar para variável de ambiente em produção**
- Senhas são hasheadas com bcrypt (cost 10)
- Cada usuário só acessa suas próprias notas (filtro `WHERE user_id = ?` em todas as queries)
- O campo `password` nunca é retornado nas respostas JSON (`json:"-"`)
- Token JWT expira em 24 horas

---
