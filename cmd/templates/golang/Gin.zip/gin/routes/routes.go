package routes

import (
	"gin/handlers"
	"gin/middleware"

	"github.com/gin-gonic/gin"
)

func Setup(r *gin.Engine) {
	api := r.Group("/api")

	// Rotas públicas
	api.POST("/register", handlers.Register)
	api.POST("/login", handlers.Login)

	// Rotas protegidas
	auth := api.Group("/")
	auth.Use(middleware.AuthRequired())
	{
		auth.GET("/notes", handlers.GetNotes)
		auth.GET("/notes/:id", handlers.GetNote)
		auth.POST("/notes", handlers.CreateNote)
		auth.PUT("/notes/:id", handlers.UpdateNote)
		auth.DELETE("/notes/:id", handlers.DeleteNote)
	}
}
