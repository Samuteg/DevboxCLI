"""
Configurações da aplicação via variáveis de ambiente.
Equivalente ao .env / application.yml dos projetos originais.
"""

import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    PORT: int = int(os.getenv("PORT", "3000"))
    JWT_SECRET: str = os.getenv("JWT_SECRET", "fallback-secret")
    JWT_EXPIRES_IN: str = os.getenv("JWT_EXPIRES_IN", "7d")
    REFRESH_TOKEN_EXPIRY_DAYS: int = int(os.getenv("REFRESH_TOKEN_EXPIRES_IN_DAYS", "30"))
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "DEBUG")

    @property
    def refresh_token_expiry_seconds(self) -> int:
        return self.REFRESH_TOKEN_EXPIRY_DAYS * 24 * 60 * 60


settings = Settings()
