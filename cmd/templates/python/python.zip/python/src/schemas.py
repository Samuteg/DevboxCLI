"""
Schemas Pydantic para validação e serialização.
Equivalente aos DTOs do Java e schemas Zod do TypeScript.
"""

from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field, EmailStr


# ── Auth ─────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="Nome do usuário")
    email: EmailStr
    password: str = Field(..., min_length=6, description="Senha (mín. 6 caracteres)")


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RefreshTokenRequest(BaseModel):
    refreshToken: str


class UserResponse(BaseModel):
    id: str
    name: str
    email: str


class AuthResponse(BaseModel):
    accessToken: str
    refreshToken: str
    user: UserResponse


class TokenRefreshResponse(BaseModel):
    accessToken: str
    refreshToken: str


class MessageResponse(BaseModel):
    message: str


# ── Notes ────────────────────────────────────────────────────────────────

class NoteRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=200, description="Título da nota")
    content: str = Field(..., min_length=1, description="Conteúdo da nota")
    tags: list[str] = Field(default_factory=list, max_length=20, description="Tags (opcional)")


class NoteResponse(BaseModel):
    id: str
    title: str
    content: str
    tags: list[str]
    createdAt: str
    updatedAt: str


class Pagination(BaseModel):
    page: int
    limit: int
    total: int
    totalPages: int


class NoteListResponse(BaseModel):
    data: list[NoteResponse]
    pagination: Pagination


# ── Error ────────────────────────────────────────────────────────────────

class ErrorResponse(BaseModel):
    message: str
    errors: Optional[dict] = None
