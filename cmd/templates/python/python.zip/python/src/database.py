"""
Camada de banco de dados SQLite com sqlite3 (stdlib).
Equivalente ao db.ts / db.js / db.rb / DbRepository.java.

Tabelas: users, notes, refresh_tokens.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DB_DIR = Path(__file__).resolve().parent.parent / "data"
DB_PATH = DB_DIR / "notes.db"


# ── Conexão ─────────────────────────────────────────────────────────────

def get_connection() -> sqlite3.Connection:
    """Retorna uma conexão com o banco SQLite (cria se não existir)."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db() -> None:
    """Inicializa o banco: cria diretório e tabelas."""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_connection()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id         TEXT PRIMARY KEY,
            name       TEXT NOT NULL,
            email      TEXT NOT NULL UNIQUE,
            password   TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS notes (
            id         TEXT PRIMARY KEY,
            user_id    TEXT NOT NULL,
            title      TEXT NOT NULL,
            content    TEXT NOT NULL,
            tags       TEXT NOT NULL DEFAULT '[]',
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS refresh_tokens (
            id          TEXT PRIMARY KEY,
            user_id     TEXT NOT NULL,
            token_hash  TEXT NOT NULL,
            expires_at  TEXT NOT NULL,
            revoked     INTEGER NOT NULL DEFAULT 0,
            created_at  TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_notes_user_id ON notes(user_id);
        CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user_id ON refresh_tokens(user_id);
    """)
    conn.commit()
    conn.close()


# ── Helpers internos ────────────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _note_from_row(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "title": row["title"],
        "content": row["content"],
        "tags": json.loads(row["tags"]) if row["tags"] else [],
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
    }


def _execute(sql: str, params: tuple = ()) -> sqlite3.Cursor:
    conn = get_connection()
    try:
        cur = conn.execute(sql, params)
        conn.commit()
        return cur
    finally:
        conn.close()


def _fetch_one(sql: str, params: tuple = ()) -> sqlite3.Row | None:
    conn = get_connection()
    try:
        cur = conn.execute(sql, params)
        return cur.fetchone()
    finally:
        conn.close()


def _fetch_all(sql: str, params: tuple = ()) -> list[sqlite3.Row]:
    conn = get_connection()
    try:
        cur = conn.execute(sql, params)
        return cur.fetchall()
    finally:
        conn.close()


# ── Usuários ────────────────────────────────────────────────────────────

def create_user(id: str, name: str, email: str, password: str) -> None:
    _execute(
        "INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)",
        (id, name, email, password),
    )


def find_user_by_email(email: str) -> sqlite3.Row | None:
    return _fetch_one("SELECT * FROM users WHERE email = ?", (email,))


def find_user_by_id(id: str) -> sqlite3.Row | None:
    return _fetch_one("SELECT * FROM users WHERE id = ?", (id,))


# ── Notas ───────────────────────────────────────────────────────────────

def create_note(
    id: str, user_id: str, title: str, content: str, tags: list[str]
) -> dict:
    now = _now_iso()
    tags_json = json.dumps(tags or [])
    _execute(
        "INSERT INTO notes (id, user_id, title, content, tags, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (id, user_id, title, content, tags_json, now, now),
    )
    return {"id": id, "title": title, "content": content, "tags": tags or [], "createdAt": now, "updatedAt": now}


def list_notes(
    user_id: str, search: str | None = None, tag: str | None = None, page: int = 1, limit: int = 10
) -> dict:
    conditions = ["user_id = ?"]
    params: list[Any] = [user_id]

    if search:
        conditions.append("(title LIKE ? OR content LIKE ?)")
        like = f"%{search}%"
        params.extend([like, like])

    if tag:
        conditions.append("tags LIKE ?")
        params.append(f'%"{tag}"%')

    where = " AND ".join(conditions)
    offset = (page - 1) * limit

    rows = _fetch_all(
        f"SELECT * FROM notes WHERE {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
        (*params, limit, offset),
    )

    count_row = _fetch_one(
        f"SELECT COUNT(*) as total FROM notes WHERE {where}", tuple(params)
    )
    total = count_row["total"] if count_row else 0
    total_pages = (total + limit - 1) // limit if total > 0 else 0

    return {
        "data": [_note_from_row(r) for r in rows],
        "pagination": {
            "page": page,
            "limit": limit,
            "total": total,
            "totalPages": total_pages,
        },
    }


def find_note_by_id(id: str, user_id: str) -> dict | None:
    row = _fetch_one(
        "SELECT * FROM notes WHERE id = ? AND user_id = ?", (id, user_id)
    )
    return _note_from_row(row) if row else None


def update_note(
    id: str, user_id: str, title: str, content: str, tags: list[str]
) -> dict | None:
    now = _now_iso()
    tags_json = json.dumps(tags or [])
    _execute(
        "UPDATE notes SET title = ?, content = ?, tags = ?, updated_at = ? WHERE id = ? AND user_id = ?",
        (title, content, tags_json, now, id, user_id),
    )
    return find_note_by_id(id, user_id)


def delete_note(id: str, user_id: str) -> bool:
    existing = find_note_by_id(id, user_id)
    if not existing:
        return False
    _execute("DELETE FROM notes WHERE id = ? AND user_id = ?", (id, user_id))
    return True


# ── Refresh Tokens ──────────────────────────────────────────────────────

def save_refresh_token(
    id: str, user_id: str, token_hash: str, expires_at: str
) -> None:
    _execute(
        "INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at) VALUES (?, ?, ?, ?)",
        (id, user_id, token_hash, expires_at),
    )


def find_refresh_token(token_hash: str) -> sqlite3.Row | None:
    return _fetch_one(
        "SELECT * FROM refresh_tokens WHERE token_hash = ? AND revoked = 0",
        (token_hash,),
    )


def revoke_refresh_token(id: str) -> None:
    _execute("UPDATE refresh_tokens SET revoked = 1 WHERE id = ?", (id,))


def revoke_all_user_refresh_tokens(user_id: str) -> None:
    _execute(
        "UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ?", (user_id,)
    )
