"""
Rotas do CRUD de notas (protegidas por JWT).
Equivalente ao routes/notes.ts / notes.rb / NoteController.java.

GET    /api/notes         (listar com paginação, busca, filtro)
GET    /api/notes/:id     (obter)
POST   /api/notes         (criar)
PUT    /api/notes/:id     (atualizar)
DELETE /api/notes/:id     (remover)
"""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status

from .auth import get_current_user
from .database import (
    create_note,
    delete_note,
    find_note_by_id,
    list_notes,
    update_note,
)
from .schemas import ErrorResponse, NoteListResponse, NoteRequest, NoteResponse

router = APIRouter(tags=["Notas"])


@router.get(
    "",
    response_model=NoteListResponse,
    summary="Listar notas com paginação, busca textual e filtro por tag",
)
def list_notes_endpoint(
    current_user: dict = Depends(get_current_user),
    page: int = Query(1, ge=1, description="Número da página"),
    limit: int = Query(10, ge=1, le=100, description="Itens por página"),
    search: str | None = Query(None, description="Busca textual no título e conteúdo"),
    tag: str | None = Query(None, description="Filtrar por tag"),
):
    return list_notes(
        user_id=current_user["id"],
        search=search,
        tag=tag,
        page=page,
        limit=limit,
    )


@router.get(
    "/{note_id}",
    response_model=NoteResponse,
    summary="Obter uma nota específica pelo ID",
    responses={404: {"model": ErrorResponse}},
)
def get_note(
    note_id: str,
    current_user: dict = Depends(get_current_user),
):
    note = find_note_by_id(note_id, current_user["id"])
    if not note:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Nota não encontrada.",
        )
    return note


@router.post(
    "",
    response_model=NoteResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Criar uma nova nota (com tags opcionais)",
    responses={400: {"model": ErrorResponse}},
)
def create_note_endpoint(
    request: NoteRequest,
    current_user: dict = Depends(get_current_user),
):
    note_id = str(uuid.uuid4())
    note = create_note(
        id=note_id,
        user_id=current_user["id"],
        title=request.title,
        content=request.content,
        tags=request.tags,
    )
    return note


@router.put(
    "/{note_id}",
    response_model=NoteResponse,
    summary="Atualizar uma nota existente (incluindo tags)",
    responses={404: {"model": ErrorResponse}},
)
def update_note_endpoint(
    note_id: str,
    request: NoteRequest,
    current_user: dict = Depends(get_current_user),
):
    note = update_note(
        id=note_id,
        user_id=current_user["id"],
        title=request.title,
        content=request.content,
        tags=request.tags,
    )
    if not note:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Nota não encontrada.",
        )
    return note


@router.delete(
    "/{note_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remover uma nota",
    responses={404: {"model": ErrorResponse}},
)
def delete_note_endpoint(
    note_id: str,
    current_user: dict = Depends(get_current_user),
):
    deleted = delete_note(note_id, current_user["id"])
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Nota não encontrada.",
        )
