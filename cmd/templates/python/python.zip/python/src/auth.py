"""
Rotas de autenticação e helpers JWT.
Equivalente ao routes/auth.ts + middleware/auth.ts dos projetos originais.

POST /api/auth/register
POST /api/auth/login
POST /api/auth/refresh
POST /api/auth/logout
GET  /api/auth/me
"""

from __future__ import annotations

import hashlib
import uuid
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .config import settings
from .database import (
    create_user,
    find_user_by_email,
    find_user_by_id,
    find_refresh_token,
    revoke_all_user_refresh_tokens,
    revoke_refresh_token,
    save_refresh_token,
)
from .schemas import (
    AuthResponse,
    LoginRequest,
    MessageResponse,
    RefreshTokenRequest,
    RegisterRequest,
    TokenRefreshResponse,
    UserResponse,
)

router = APIRouter(tags=["Autenticação"])
security = HTTPBearer(auto_error=False)

# ── Constantes ──────────────────────────────────────────────────────────

ALGORITHM = "HS256"
REFRESH_TOKEN_EXPIRY_SECONDS = 30 * 24 * 60 * 60  # 30 dias


# ── Helpers JWT ─────────────────────────────────────────────────────────

def _parse_duration(duration: str) -> int:
    """Converte string como '15m', '1h', '7d' para segundos."""
    duration = duration.strip().lower()
    if duration.endswith("m"):
        return int(duration[:-1]) * 60
    elif duration.endswith("h"):
        return int(duration[:-1]) * 3600
    elif duration.endswith("d"):
        return int(duration[:-1]) * 86400
    return 7 * 86400  # padrão: 7 dias


def _create_access_token(payload: dict) -> str:
    """Gera um access token JWT com exp baseada em JWT_EXPIRES_IN."""
    to_encode = payload.copy()
    expires_in = _parse_duration(settings.JWT_EXPIRES_IN)
    expire = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
    to_encode["exp"] = expire
    return jwt.encode(to_encode, settings.JWT_SECRET, algorithm=ALGORITHM)


def _hash_token(token: str) -> str:
    """Hash SHA-256 de um token (para refresh tokens)."""
    return hashlib.sha256(token.encode()).hexdigest()


# ── Dependência de autenticação ─────────────────────────────────────────

def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(security),
) -> dict:
    """
    Dependência FastAPI que extrai e valida o token JWT.
    Equivalente ao authenticate! nos projetos Ruby e middleware/auth.ts.
    """
    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido ou não fornecido.",
        )
    token = credentials.credentials
    try:
        payload = jwt.decode(
            token, settings.JWT_SECRET, algorithms=[ALGORITHM]
        )
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expirado.",
        )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido ou não fornecido.",
        )


# ── Rotas ───────────────────────────────────────────────────────────────

@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Cadastrar um novo usuário",
)
def register(request: RegisterRequest):
    email = request.email.strip().lower()

    if find_user_by_email(email):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="E-mail já cadastrado.",
        )

    hashed = bcrypt.hashpw(
        request.password.encode(), bcrypt.gensalt()
    ).decode()
    user_id = str(uuid.uuid4())

    create_user(user_id, request.name, email, hashed)

    return {"id": user_id, "name": request.name, "email": email}


@router.post(
    "/login",
    response_model=AuthResponse,
    summary="Autenticar e obter access token + refresh token",
)
def login(request: LoginRequest):
    email = request.email.strip().lower()
    user = find_user_by_email(email)

    if not user or not bcrypt.checkpw(
        request.password.encode(), user["password"].encode()
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciais inválidas.",
        )

    # Access token
    access_token = _create_access_token(
        {"id": user["id"], "name": user["name"], "email": user["email"]}
    )

    # Refresh token
    raw_refresh_token = str(uuid.uuid4())
    token_hash = _hash_token(raw_refresh_token)
    expires_at = (
        datetime.now(timezone.utc) + timedelta(seconds=REFRESH_TOKEN_EXPIRY_SECONDS)
    ).isoformat().replace("+00:00", "Z")

    save_refresh_token(
        str(uuid.uuid4()), user["id"], token_hash, expires_at
    )

    return {
        "accessToken": access_token,
        "refreshToken": raw_refresh_token,
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
        },
    }


@router.post(
    "/refresh",
    response_model=TokenRefreshResponse,
    summary="Renovar access token usando refresh token",
)
def refresh(request: RefreshTokenRequest):
    token_hash = _hash_token(request.refreshToken)
    stored = find_refresh_token(token_hash)

    if not stored:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token inválido ou já utilizado.",
        )

    # Verifica expiração
    expires_at = datetime.fromisoformat(stored["expires_at"].replace("Z", "+00:00"))
    if expires_at < datetime.now(timezone.utc):
        revoke_refresh_token(stored["id"])
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token expirado.",
        )

    # Revoga o token atual (rotação)
    revoke_refresh_token(stored["id"])

    # Busca o usuário
    user = find_user_by_id(stored["user_id"])
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuário não encontrado.",
        )

    # Novo access token
    new_access_token = _create_access_token(
        {"id": user["id"], "name": user["name"], "email": user["email"]}
    )

    # Novo refresh token
    new_raw_refresh_token = str(uuid.uuid4())
    new_token_hash = _hash_token(new_raw_refresh_token)
    new_expires_at = (
        datetime.now(timezone.utc) + timedelta(seconds=REFRESH_TOKEN_EXPIRY_SECONDS)
    ).isoformat().replace("+00:00", "Z")

    save_refresh_token(
        str(uuid.uuid4()), user["id"], new_token_hash, new_expires_at
    )

    return {
        "accessToken": new_access_token,
        "refreshToken": new_raw_refresh_token,
    }


@router.post(
    "/logout",
    response_model=MessageResponse,
    summary="Revogar todos os refresh tokens do usuário (logout)",
)
def logout(current_user: dict = Depends(get_current_user)):
    revoke_all_user_refresh_tokens(current_user["id"])
    return {"message": "Logout realizado com sucesso."}


@router.get(
    "/me",
    response_model=UserResponse,
    summary="Retorna os dados do usuário autenticado",
)
def me(current_user: dict = Depends(get_current_user)):
    return {
        "id": current_user["id"],
        "name": current_user["name"],
        "email": current_user["email"],
    }
