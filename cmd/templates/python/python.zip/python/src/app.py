"""
Aplicação principal FastAPI.
Equivalente ao app.ts / app.js / app.rb / NotesCrudApplication.java.

Inicializa o banco SQLite, configura middlewares e registra as rotas.
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .auth import router as auth_router
from .config import settings
from .database import init_db
from .notes import router as notes_router

load_dotenv()

# ── Logger ──────────────────────────────────────────────────────────────

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL, logging.DEBUG),
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("notes-crud")


# ── Lifespan ────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Inicializa o banco ao iniciar a aplicação."""
    logger.info("Inicializando banco SQLite...")
    init_db()
    logger.info("Banco de dados inicializado com sucesso")
    yield


# ── App ─────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Notes CRUD API",
    description="API RESTful para gerenciamento de notas com autenticação JWT",
    version="2.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url=None,
)


# ── CORS ────────────────────────────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Rate Limiting (middleware simples) ──────────────────────────────────

_request_timestamps: dict[str, list[float]] = defaultdict(list)
MAX_REQUESTS = 100
WINDOW_SECONDS = 60


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    """Rate limiting: 100 requisições por minuto por IP."""
    ip = request.client.host if request.client else "unknown"
    now = time.time()

    timestamps = _request_timestamps[ip]
    # Remove timestamps expirados
    _request_timestamps[ip] = [t for t in timestamps if now - t < WINDOW_SECONDS]

    if len(_request_timestamps[ip]) >= MAX_REQUESTS:
        logger.warning("Rate limit excedido para IP: %s", ip)
        return JSONResponse(
            status_code=429,
            content={"message": "Muitas requisições. Tente novamente em 1 minuto."},
        )

    _request_timestamps[ip].append(now)
    return await call_next(request)


# ── Rotas ───────────────────────────────────────────────────────────────

app.include_router(auth_router, prefix="/api/auth")
app.include_router(notes_router, prefix="/api/notes")


# ── Health Check ───────────────────────────────────────────────────────

@app.get("/health", tags=["Sistema"])
async def health():
    return {
        "status": "ok",
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }


# ── Inicialização direta ────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    port = settings.PORT
    print(f"🚀  Servidor rodando em http://localhost:{port}")
    print(f"📄  Documentação Swagger em http://localhost:{port}/docs")
    uvicorn.run("src.app:app", host="0.0.0.0", port=port, reload=True)
