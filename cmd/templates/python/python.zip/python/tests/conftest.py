"""Fixtures pytest para os testes da API de notas.

Configura um banco SQLite temporário em vez do arquivo ``data/notes.db``
para isolar os testes do ambiente de desenvolvimento, e fornece fixtures
de cliente HTTP, usuário autenticado e tokens.
"""

from __future__ import annotations

import atexit
import os
import tempfile
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

# ── Banco temporário ─────────────────────────────────────────────────────
# Sobrescreve DB_PATH *antes* de qualquer outro módulo da aplicação ser
# importado, garantindo que os helpers em src.database usem o arquivo
# temporário durante toda a sessão de testes.

import src.database as _db

_tmp_fd, _tmp_path = tempfile.mkstemp(suffix="_notes_test.db")
os.close(_tmp_fd)
_db.DB_PATH = Path(_tmp_path)
_db.init_db()

# Limpeza ao final do processo (os testes podem rodar em modo `-x` e abortar)
atexit.register(lambda p=Path(_tmp_path): p.unlink(missing_ok=True))

from src.app import app


# ── Fixtures ─────────────────────────────────────────────────────────────


@pytest.fixture
def client():
    """Cliente HTTP síncrono para testes com a aplicação FastAPI.

    Usa :class:`fastapi.testclient.TestClient` internamente, que já
    gerencia os eventos de *lifespan* da aplicação.
    """
    with TestClient(app) as c:
        yield c


@pytest.fixture
def user(client):
    """Registra um usuário único e retorna suas credenciais.

    Cada chamada gera um e-mail diferente, evitando conflitos de
    ``UNIQUE`` entre testes.
    """
    email = f"user-{uuid.uuid4()}@test.com"
    resp = client.post(
        "/api/auth/register",
        json={"name": "Teste", "email": email, "password": "123456"},
    )
    assert resp.status_code == 201
    return {"name": "Teste", "email": email, "password": "123456"}


@pytest.fixture
def auth(client, user):
    """Faz login com o usuário criado em :func:`user` e retorna os tokens
    de acesso, *refresh* e os dados do usuário."""
    resp = client.post(
        "/api/auth/login",
        json={"email": user["email"], "password": user["password"]},
    )
    assert resp.status_code == 200
    body = resp.json()
    return {
        "accessToken": body["accessToken"],
        "refreshToken": body["refreshToken"],
        "user": body["user"],
    }


@pytest.fixture
def headers(auth):
    """Headers prontos com ``Authorization: Bearer <token>``."""
    return {"Authorization": f"Bearer {auth['accessToken']}"}
