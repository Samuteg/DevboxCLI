"""Testes de autenticação.

Cobre os endpoints públicos e protegidos do módulo ``src/auth.py``:

- POST /api/auth/register
- POST /api/auth/login
- POST /api/auth/refresh
- POST /api/auth/logout
- GET  /api/auth/me
"""

from __future__ import annotations

import uuid

import pytest


class TestRegister:
    """POST /api/auth/register — Cadastro de usuário."""

    def test_success(self, client):
        """Deve cadastrar um novo usuário com dados válidos."""
        resp = client.post(
            "/api/auth/register",
            json={
                "name": "João Silva",
                "email": "joao@email.com",
                "password": "123456",
            },
        )
        assert resp.status_code == 201
        body = resp.json()
        assert "id" in body
        assert body["name"] == "João Silva"
        assert body["email"] == "joao@email.com"
        # A senha nunca deve ser retornada
        assert "password" not in body

    def test_duplicate_email(self, client):
        """Deve rejeitar cadastro com e-mail já existente (409)."""
        data = {
            "name": "João",
            "email": "dup@email.com",
            "password": "123456",
        }
        # Primeiro cadastro — sucesso
        assert client.post("/api/auth/register", json=data).status_code == 201
        # Segundo cadastro — conflito
        resp = client.post("/api/auth/register", json=data)
        assert resp.status_code == 409
        assert resp.json()["detail"] == "E-mail já cadastrado."

    def test_invalid_data(self, client):
        """Deve retornar 422 para dados inválidos (nome vazio, e-mail
        mal-formado, senha curta)."""
        resp = client.post(
            "/api/auth/register",
            json={
                "name": "",  # min_length=1
                "email": "invalido",  # EmailStr
                "password": "12",  # min_length=6
            },
        )
        assert resp.status_code == 422


class TestLogin:
    """POST /api/auth/login — Autenticação."""

    def test_success(self, client, user):
        """Deve autenticar e retornar accessToken, refreshToken e user."""
        resp = client.post(
            "/api/auth/login",
            json={"email": user["email"], "password": user["password"]},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert "accessToken" in body
        assert "refreshToken" in body
        assert "user" in body
        assert body["user"]["name"] == user["name"]
        assert body["user"]["email"] == user["email"]
        assert "id" in body["user"]

    def test_invalid_credentials(self, client, user):
        """Deve rejeitar login com senha incorreta (401)."""
        resp = client.post(
            "/api/auth/login",
            json={"email": user["email"], "password": "senha_errada"},
        )
        assert resp.status_code == 401
        assert "Credenciais inválidas" in resp.json()["detail"]


class TestMe:
    """GET /api/auth/me — Dados do usuário autenticado."""

    def test_with_token(self, client, auth):
        """Deve retornar os dados do usuário com token válido."""
        resp = client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {auth['accessToken']}"},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["email"] == auth["user"]["email"]
        assert body["name"] == auth["user"]["name"]
        assert "id" in body

    def test_without_token(self, client):
        """Deve rejeitar requisição sem token (401)."""
        resp = client.get("/api/auth/me")
        assert resp.status_code == 401


class TestRefresh:
    """POST /api/auth/refresh — Renovação de access token."""

    def test_success(self, client, auth):
        """Deve renovar o access token e gerar um novo refresh token
        (rotação)."""
        resp = client.post(
            "/api/auth/refresh",
            json={"refreshToken": auth["refreshToken"]},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert "accessToken" in body
        assert "refreshToken" in body
        # O refresh token deve ser diferente do anterior (rotação)
        assert body["refreshToken"] != auth["refreshToken"]

    def test_invalid_token(self, client):
        """Deve rejeitar refresh token inválido (401)."""
        resp = client.post(
            "/api/auth/refresh",
            json={"refreshToken": "00000000-0000-0000-0000-000000000000"},
        )
        assert resp.status_code == 401


class TestLogout:
    """POST /api/auth/logout — Revogação de tokens."""

    def test_success(self, client, auth):
        """Deve revogar todos os refresh tokens do usuário."""
        resp = client.post(
            "/api/auth/logout",
            headers={"Authorization": f"Bearer {auth['accessToken']}"},
        )
        assert resp.status_code == 200
        assert resp.json()["message"] == "Logout realizado com sucesso."

    def test_refresh_after_logout(self, client):
        """Deve rejeitar refresh token após logout (401)."""
        # Cria um usuário do zero para este teste
        email = f"logout-{uuid.uuid4()}@test.com"
        client.post(
            "/api/auth/register",
            json={"name": "Logout", "email": email, "password": "123456"},
        )
        login_resp = client.post(
            "/api/auth/login",
            json={"email": email, "password": "123456"},
        )
        body = login_resp.json()
        access_token = body["accessToken"]
        refresh_token = body["refreshToken"]

        # Logout
        client.post(
            "/api/auth/logout",
            headers={"Authorization": f"Bearer {access_token}"},
        )

        # Refresh pós-logout deve falhar
        resp = client.post(
            "/api/auth/refresh",
            json={"refreshToken": refresh_token},
        )
        assert resp.status_code == 401
