"""Testes do CRUD de notas (protegido por JWT).

Cobre os endpoints do módulo ``src/notes.py``:

- POST   /api/notes
- GET    /api/notes
- GET    /api/notes/{id}
- PUT    /api/notes/{id}
- DELETE /api/notes/{id}
"""

from __future__ import annotations

import pytest


class TestCreateNote:
    """POST /api/notes — Criar nota."""

    def test_with_tags(self, client, headers):
        """Deve criar nota com tags e retornar 201."""
        resp = client.post(
            "/api/notes",
            json={
                "title": "Minha nota",
                "content": "Conteúdo da nota",
                "tags": ["estudo", "python"],
            },
            headers=headers,
        )
        assert resp.status_code == 201
        body = resp.json()
        assert body["title"] == "Minha nota"
        assert body["content"] == "Conteúdo da nota"
        assert body["tags"] == ["estudo", "python"]
        assert "id" in body
        assert "createdAt" in body
        assert "updatedAt" in body

    def test_empty_title(self, client, headers):
        """Deve rejeitar título vazio (422)."""
        resp = client.post(
            "/api/notes",
            json={"title": "", "content": "Conteúdo"},
            headers=headers,
        )
        assert resp.status_code == 422


class TestListNotes:
    """GET /api/notes — Listar notas."""

    def test_pagination(self, client, headers):
        """Deve listar notas com paginação."""
        # Cria ao menos uma nota para o usuário
        client.post(
            "/api/notes",
            json={"title": "Nota A", "content": "Conteúdo A"},
            headers=headers,
        )

        resp = client.get("/api/notes?page=1&limit=10", headers=headers)
        assert resp.status_code == 200
        body = resp.json()
        assert "data" in body
        assert "pagination" in body
        assert body["pagination"]["page"] == 1
        assert body["pagination"]["limit"] == 10
        assert body["pagination"]["total"] >= 1
        assert len(body["data"]) >= 1

    def test_search_by_text(self, client, headers):
        """Deve buscar notas por texto no título/conteúdo."""
        client.post(
            "/api/notes",
            json={
                "title": "Estudar Python",
                "content": "Conteúdo sobre a linguagem",
            },
            headers=headers,
        )

        resp = client.get("/api/notes?search=Python", headers=headers)
        assert resp.status_code == 200
        body = resp.json()
        assert len(body["data"]) >= 1
        # O termo buscado deve estar presente no título ou conteúdo
        note = body["data"][0]
        assert "Python" in note["title"] or "Python" in note["content"]

    def test_filter_by_tag(self, client, headers):
        """Deve filtrar notas por tag específica."""
        client.post(
            "/api/notes",
            json={
                "title": "Nota com tag",
                "content": "Conteúdo",
                "tags": ["estudo", "python"],
            },
            headers=headers,
        )

        resp = client.get("/api/notes?tag=python", headers=headers)
        assert resp.status_code == 200
        body = resp.json()
        assert len(body["data"]) >= 1
        assert all("python" in n["tags"] for n in body["data"])

    def test_without_token(self, client):
        """Deve rejeitar requisição sem token (401)."""
        resp = client.get("/api/notes")
        assert resp.status_code == 401


class TestGetNote:
    """GET /api/notes/{id} — Obter nota por ID."""

    def test_success(self, client, headers):
        """Deve retornar a nota quando ela existe."""
        create_resp = client.post(
            "/api/notes",
            json={"title": "Minha nota", "content": "Conteúdo"},
            headers=headers,
        )
        note_id = create_resp.json()["id"]

        resp = client.get(f"/api/notes/{note_id}", headers=headers)
        assert resp.status_code == 200
        assert resp.json()["id"] == note_id
        assert resp.json()["title"] == "Minha nota"

    def test_not_found(self, client, headers):
        """Deve retornar 404 para ID inexistente."""
        resp = client.get("/api/notes/id-inexistente", headers=headers)
        assert resp.status_code == 404


class TestUpdateNote:
    """PUT /api/notes/{id} — Atualizar nota."""

    def test_success(self, client, headers):
        """Deve atualizar título, conteúdo e tags."""
        create_resp = client.post(
            "/api/notes",
            json={
                "title": "Original",
                "content": "Conteúdo original",
                "tags": ["um"],
            },
            headers=headers,
        )
        note_id = create_resp.json()["id"]

        resp = client.put(
            f"/api/notes/{note_id}",
            json={
                "title": "Atualizado",
                "content": "Conteúdo atualizado",
                "tags": ["um", "dois"],
            },
            headers=headers,
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["title"] == "Atualizado"
        assert body["content"] == "Conteúdo atualizado"
        assert "dois" in body["tags"]
        # createdAt deve ser preservado (não mudou)
        assert body["createdAt"] == create_resp.json()["createdAt"]

    def test_not_found(self, client, headers):
        """Deve retornar 404 ao atualizar nota inexistente."""
        resp = client.put(
            "/api/notes/id-fake",
            json={"title": "X", "content": "Y"},
            headers=headers,
        )
        assert resp.status_code == 404


class TestDeleteNote:
    """DELETE /api/notes/{id} — Remover nota."""

    def test_success(self, client, headers):
        """Deve remover a nota e retornar 204."""
        create_resp = client.post(
            "/api/notes",
            json={"title": "Para deletar", "content": "Conteúdo"},
            headers=headers,
        )
        note_id = create_resp.json()["id"]

        resp = client.delete(f"/api/notes/{note_id}", headers=headers)
        assert resp.status_code == 204
        # Confirma que a nota foi removida
        get_resp = client.get(f"/api/notes/{note_id}", headers=headers)
        assert get_resp.status_code == 404

    def test_not_found(self, client, headers):
        """Deve retornar 404 ao remover nota inexistente."""
        resp = client.delete("/api/notes/id-fake", headers=headers)
        assert resp.status_code == 404
