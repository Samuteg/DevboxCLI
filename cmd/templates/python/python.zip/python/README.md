# ✍️ Notes CRUD API v2.0.0 — Python (FastAPI)

API RESTful de notas com autenticação JWT, refresh token com rotação, tags, paginação, busca textual e documentação Swagger interativa — em **Python** com **FastAPI**.

Este projeto é a versão **Python** dos templates [TypeScript](../ts/), [JavaScript](../js/), [Ruby](../ruby/) e [Java](../java/), mantendo as mesmas funcionalidades, estrutura e padrões de código.

## 📋 Índice

- [Funcionalidades](#-funcionalidades)
- [Tecnologias](#-tecnologias)
- [Comparativo com outras versões](#-comparativo-com-outras-versões)
- [Pré-requisitos](#-pré-requisitos)
- [Instalação e execução](#-instalação-e-execução)
- [Variáveis de ambiente](#-variáveis-de-ambiente)
- [Scripts disponíveis](#-scripts-disponíveis)
- [Documentação Swagger](#-documentação-swagger)
- [Estrutura do projeto](#-estrutura-do-projeto)
- [Endpoints](#-endpoints)
  - [Autenticação](#-autenticação)
  - [Notas](#-notas)
- [Fluxo de uso](#-fluxo-de-uso)
- [Exemplo completo com cURL](#-exemplo-completo-com-curl)
- [Docker](#-docker)
- [Testes](#-testes)
- [Licença](#-licença)

---

## ✨ Funcionalidades

- ✅ Cadastro e autenticação de usuários (JWT + bcrypt)
- ✅ Refresh token com rotação (SHA-256)
- ✅ CRUD completo de notas com isolamento por usuário
- ✅ Tags nas notas (array de strings)
- ✅ Paginação (`page`/`limit`)
- ✅ Busca textual no título e conteúdo (`search`)
- ✅ Filtro por tag (`tag`)
- ✅ Rate limiting (100 requisições/min por IP)
- ✅ Documentação Swagger UI automática em `/docs`
- ✅ CORS habilitado
- ✅ Logs estruturados (stdlib `logging`)
- ✅ Testes automatizados (pytest + httpx)
- ✅ Docker pronto (Alpine, multi-stage)

---

## 🛠 Tecnologias

| Tecnologia               | Versão   | Finalidade                              |
| ------------------------ | -------- | --------------------------------------- |
| **Python**               | ≥ 3.10   | Linguagem                               |
| **FastAPI**              | ≥ 0.115  | Framework web (ASGI)                    |
| **Uvicorn**              | ≥ 0.34   | Servidor ASGI                           |
| **Pydantic v2**          | ≥ 2.10   | Validação de dados (schemas + EmailStr) |
| **PyJWT**                | ≥ 2.10   | Geração e verificação de tokens JWT     |
| **Bcrypt**               | ≥ 4.2    | Hash de senhas                          |
| **SQLite3**              | —        | Banco de dados (stdlib)                 |
| **python-dotenv**        | ≥ 1.0    | Carregamento de variáveis de ambiente   |
| **pytest**               | ≥ 8.0    | Testes automatizados                    |
| **httpx**                | ≥ 0.28   | Cliente HTTP para testes (ASGI)         |

---

## 📊 Comparativo com outras versões

| Funcionalidade      | TypeScript / JS       | Ruby               | Java                         | **Python**                |
| ------------------- | --------------------- | ------------------ | ---------------------------- | ------------------------- |
| **Framework**       | Fastify               | Sinatra            | Spring Boot 3                | **FastAPI**               |
| **Banco**           | sql.js (WASM)         | sqlite3 (gem)      | SQLite + JdbcTemplate        | **SQLite3 (stdlib)**      |
| **Validação**       | Zod                   | Manual             | Jakarta Validation           | **Pydantic v2**           |
| **Logger**          | Pino                  | Logger (stdlib)    | SLF4J + Logback              | **logging (stdlib)**      |
| **Testes**          | Vitest                | Minitest           | JUnit 5 + MockMvc            | **pytest + httpx**        |
| **UUID**            | uuid (lib)            | SecureRandom       | UUID (java.util)             | **uuid (stdlib)**         |
| **Autenticação**    | @fastify/jwt          | jwt gem            | jjwt + Spring Security       | **PyJWT + Depends**       |
| **Swagger**         | @fastify/swagger      | openapi.json       | springdoc                    | **FastAPI (built-in)**    |

---

## 📋 Pré-requisitos

- **Python** 3.10 ou superior
- **pip** (gerenciador de pacotes)

Verifique as versões instaladas:

```bash
python --version   # Python ≥ 3.10
pip --version
```

---

## 🚀 Instalação e execução

```bash
# 1. Acesse a pasta da versão Python
cd templates/python

# 2. (Opcional) Crie e ative um ambiente virtual
python -m venv .venv
source .venv/bin/activate   # Linux/macOS
# .venv\Scripts\activate    # Windows

# 3. Instale as dependências
pip install -r requirements.txt

# 4. Inicie o servidor
python -m src.app
```

O servidor subirá em **http://localhost:3000**.

---

## 🔐 Variáveis de Ambiente

| Variável                        | Padrão            | Descrição                                |
| ------------------------------- | ----------------- | ---------------------------------------- |
| `PORT`                          | `3000`            | Porta do servidor HTTP                   |
| `JWT_SECRET`                    | `fallback-secret` | Chave secreta para assinar tokens JWT    |
| `JWT_EXPIRES_IN`                | `7d`              | Tempo de expiração do access token       |
| `REFRESH_TOKEN_EXPIRES_IN_DAYS` | `30`              | Dias de validade do refresh token        |
| `LOG_LEVEL`                     | `DEBUG`           | Nível de log (`DEBUG`, `INFO`, `WARN`)   |

> ⚠️ Em produção, defina uma `JWT_SECRET` forte (mínimo 32 caracteres aleatórios).

---

## 📜 Scripts disponíveis

| Comando                     | Descrição                                       |
| --------------------------- | ----------------------------------------------- |
| `python -m src.app`         | Inicia o servidor (porta 3000)                  |
| `uvicorn src.app:app --reload` | Inicia com *hot reload* (desenvolvimento)    |
| `pytest`                    | Executa todos os testes                         |
| `pytest -v`                 | Executa testes com saída verbosa                |
| `pytest tests/test_auth.py` | Executa apenas os testes de autenticação        |
| `pytest tests/test_notes.py`| Executa apenas os testes de notas               |

---

## 📖 Documentação Swagger

**Diferentemente das versões JS/TS/Ruby/Java**, o FastAPI **gera automaticamente** a documentação Swagger (OpenAPI 3.0) sem necessidade de configuração adicional ou bibliotecas extras.

Com o servidor rodando, acesse:

```
http://localhost:3000/docs
```

A interface Swagger UI permite:

- Visualizar todos os endpoints, schemas e códigos de resposta
- Clicar em **Authorize** e colar o token JWT (`Bearer <token>`) para testar rotas protegidas
- Executar requisições diretamente pelo navegador

> O Swagger também está disponível no formato JSON em `http://localhost:3000/openapi.json`.

---

## 📁 Estrutura do projeto

```
python/
├── src/
│   ├── __init__.py
│   ├── app.py          # Aplicação FastAPI (lifespan, middlewares, rotas)
│   ├── auth.py         # Rotas de autenticação + helpers JWT
│   ├── config.py       # Configurações via variáveis de ambiente
│   ├── database.py     # Camada SQLite (tabelas, queries, persistência)
│   ├── notes.py        # CRUD de notas (protegido por JWT)
│   └── schemas.py      # Schemas Pydantic (validação e serialização)
├── tests/
│   ├── __init__.py
│   ├── conftest.py     # Fixtures pytest (banco temp, client, tokens)
│   ├── test_auth.py    # Testes de autenticação
│   └── test_notes.py   # Testes do CRUD de notas
├── data/               # Diretório onde o SQLite é persistido (gitignored)
├── .env.example        # Template das variáveis de ambiente
├── .gitignore
├── .dockerignore
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md
```

---

## 📡 Endpoints

### 🔑 Autenticação

| Método | Rota                    | Descrição                         | Autenticação |
| ------ | ----------------------- | --------------------------------- | ------------ |
| POST   | `/api/auth/register`    | Cadastrar novo usuário            | ❌           |
| POST   | `/api/auth/login`       | Login e retorno dos tokens        | ❌           |
| POST   | `/api/auth/refresh`     | Renovar access token com refresh  | ❌           |
| POST   | `/api/auth/logout`      | Revogar todos os refresh tokens   | ✅           |
| GET    | `/api/auth/me`          | Dados do usuário autenticado      | ✅           |

#### `POST /api/auth/register`

**Body:**
```json
{
  "name": "João Silva",
  "email": "joao@email.com",
  "password": "123456"
}
```

**Resposta (201):**
```json
{
  "id": "uuid",
  "name": "João Silva",
  "email": "joao@email.com"
}
```

**Erros:**
| Código | Descrição                     |
| ------ | ----------------------------- |
| 409    | E-mail já cadastrado          |
| 422    | Dados inválidos (validação)   |

#### `POST /api/auth/login`

**Body:**
```json
{
  "email": "joao@email.com",
  "password": "123456"
}
```

**Resposta (200):**
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIs...",
  "refreshToken": "uuid-v4",
  "user": {
    "id": "uuid",
    "name": "João Silva",
    "email": "joao@email.com"
  }
}
```

**Erros:**
| Código | Descrição                     |
| ------ | ----------------------------- |
| 401    | Credenciais inválidas         |

#### `POST /api/auth/refresh`

**Body:**
```json
{
  "refreshToken": "uuid-v4-recebido-no-login"
}
```

**Resposta (200):**
```json
{
  "accessToken": "novo-access-token",
  "refreshToken": "novo-refresh-token"
}
```

> 🔄 O refresh token anterior é revogado (rotação). O novo refresh token deve ser armazenado pelo cliente.

**Erros:**
| Código | Descrição                               |
| ------ | --------------------------------------- |
| 401    | Refresh token inválido, expirado ou já utilizado |

#### `POST /api/auth/logout`

**Headers:** `Authorization: Bearer <accessToken>`

**Resposta (200):**
```json
{
  "message": "Logout realizado com sucesso."
}
```

> 🔒 Todos os refresh tokens do usuário são revogados.

#### `GET /api/auth/me`

**Headers:** `Authorization: Bearer <accessToken>`

**Resposta (200):**
```json
{
  "id": "uuid",
  "name": "João Silva",
  "email": "joao@email.com"
}
```

---

### 📝 Notas

| Método | Rota              | Descrição                       | Autenticação |
| ------ | ----------------- | ------------------------------- | ------------ |
| POST   | `/api/notes`      | Criar nova nota (com tags)      | ✅           |
| GET    | `/api/notes`      | Listar notas (paginação, busca) | ✅           |
| GET    | `/api/notes/:id`  | Obter nota por ID               | ✅           |
| PUT    | `/api/notes/:id`  | Atualizar nota (incluindo tags) | ✅           |
| DELETE | `/api/notes/:id`  | Remover nota                    | ✅           |

Todos os endpoints de notas exigem o header:

```
Authorization: Bearer <accessToken>
```

#### `POST /api/notes`

**Body:**
```json
{
  "title": "Minha nota",
  "content": "Conteúdo da nota",
  "tags": ["estudo", "fastapi"]
}
```

**Resposta (201):**
```json
{
  "id": "uuid",
  "title": "Minha nota",
  "content": "Conteúdo da nota",
  "tags": ["estudo", "fastapi"],
  "createdAt": "2026-07-09T16:35:49.938Z",
  "updatedAt": "2026-07-09T16:35:49.938Z"
}
```

**Erros:**
| Código | Descrição                     |
| ------ | ----------------------------- |
| 422    | Dados inválidos (ex: título vazio) |

#### `GET /api/notes`

**Query params:**

| Parâmetro | Tipo    | Padrão | Descrição                            |
| --------- | ------- | ------ | ------------------------------------ |
| `page`    | integer | 1      | Número da página                     |
| `limit`   | integer | 10     | Itens por página (máx. 100)          |
| `search`  | string  | —      | Busca textual no título e conteúdo   |
| `tag`     | string  | —      | Filtrar por tag específica           |

**Resposta (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "title": "Minha nota",
      "content": "Conteúdo da nota",
      "tags": ["estudo", "fastapi"],
      "createdAt": "2026-07-09T16:35:49.938Z",
      "updatedAt": "2026-07-09T16:35:49.938Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "totalPages": 1
  }
}
```

#### `GET /api/notes/:id`

**Resposta (200):**
```json
{
  "id": "uuid",
  "title": "Minha nota",
  "content": "Conteúdo da nota",
  "tags": ["estudo"],
  "createdAt": "2026-07-09T16:35:49.938Z",
  "updatedAt": "2026-07-09T16:35:49.938Z"
}
```

**Resposta (404):**
```json
{
  "detail": "Nota não encontrada."
}
```

#### `PUT /api/notes/:id`

**Body:**
```json
{
  "title": "Título atualizado",
  "content": "Conteúdo atualizado",
  "tags": ["estudo", "python"]
}
```

**Resposta (200):**
```json
{
  "id": "uuid",
  "title": "Título atualizado",
  "content": "Conteúdo atualizado",
  "tags": ["estudo", "python"],
  "createdAt": "2026-07-09T16:35:49.938Z",
  "updatedAt": "2026-07-09T18:00:00.000Z"
}
```

#### `DELETE /api/notes/:id`

**Resposta:** `204 No Content` (sem corpo)

---

## 🔄 Fluxo de uso

```mermaid
sequenceDiagram
    participant C as Cliente
    participant API as API (FastAPI)
    participant DB as SQLite

    C->>API: POST /api/auth/register
    API->>DB: Armazena usuário (bcrypt hash)
    API-->>C: 201 { id, name, email }

    C->>API: POST /api/auth/login
    API->>DB: Busca usuário e compara bcrypt
    API->>DB: Salva refresh token (SHA-256 hash)
    API-->>C: 200 { accessToken, refreshToken, user }

    C->>API: POST /api/notes (Bearer accessToken)
    Note over API: Verifica JWT (dependência get_current_user)
    API->>DB: Armazena nota com tags
    API-->>C: 201 { id, title, content, tags, createdAt, updatedAt }

    C->>API: GET /api/notes?page=1&limit=10&search=algo&tag=estudo
    Note over API: Verifica JWT
    API->>DB: Query com LIKE + filtros + paginação
    API-->>C: 200 { data[], pagination }

    C->>API: POST /api/auth/refresh
    API->>DB: Revoga token antigo (rotação)
    API->>DB: Salva novo refresh token
    API-->>C: 200 { accessToken, refreshToken }

    C->>API: POST /api/auth/logout (Bearer accessToken)
    API->>DB: Revoga todos os refresh tokens do usuário
    API-->>C: 200 { message }
```

---

## 🧪 Exemplo completo com cURL

```bash
# 1. Registrar
curl -s -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Maria","email":"maria@email.com","password":"123456"}'

# 2. Login (guarde os tokens)
RESP=$(curl -s -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"maria@email.com","password":"123456"}')
ACCESS_TOKEN=$(echo $RESP | python3 -c "import sys,json; print(json.load(sys.stdin)['accessToken'])")
REFRESH_TOKEN=$(echo $RESP | python3 -c "import sys,json; print(json.load(sys.stdin)['refreshToken'])")

# 3. Criar nota com tags
curl -s -X POST http://localhost:3000/api/notes \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -d '{"title":"Estudar FastAPI","content":"Ver documentação oficial","tags":["estudo","python"]}'

# 4. Listar notas com paginação
curl -s "http://localhost:3000/api/notes?page=1&limit=10" \
  -H "Authorization: Bearer $ACCESS_TOKEN" | python3 -m json.tool

# 5. Buscar notas por texto
curl -s "http://localhost:3000/api/notes?search=FastAPI" \
  -H "Authorization: Bearer $ACCESS_TOKEN" | python3 -m json.tool

# 6. Renovar tokens
curl -s -X POST http://localhost:3000/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d "{\"refreshToken\": \"$REFRESH_TOKEN\"}"

# 7. Verificar dados do usuário
curl -s http://localhost:3000/api/auth/me \
  -H "Authorization: Bearer $ACCESS_TOKEN" | python3 -m json.tool

# 8. Logout
curl -s -X POST http://localhost:3000/api/auth/logout \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

---

## 🐳 Docker

```bash
# Construir e iniciar
docker compose up -d

# Ver logs
docker compose logs -f

# Parar
docker compose down
```

A API estará disponível em `http://localhost:3000` e a documentação em `http://localhost:3000/docs`.

O banco SQLite é persistido em um volume Docker (`notes_data`), garantindo que os dados sobrevivam ao ciclo de vida do container.

---

## 🧪 Testes

```bash
# Executar todos os testes
pytest

# Com saída verbosa
pytest -v

# Apenas testes de autenticação
pytest tests/test_auth.py -v

# Apenas testes de notas
pytest tests/test_notes.py -v
```

O projeto possui **22 testes automatizados** cobrindo:

- **Autenticação (10 testes):** register (sucesso, duplicado, dados inválidos), login (sucesso, credenciais inválidas), `/me` (com e sem token), refresh (sucesso, token inválido), logout, refresh pós-logout
- **Notas (12 testes):** create (com tags, dados inválidos), list (paginação, busca textual, filtro por tag, sem token), get by ID (sucesso, 404), update (sucesso, 404), delete (sucesso, 404)

Os testes usam `pytest` + `httpx` com `TestClient` do FastAPI, que faz requisições HTTP simuladas sem precisar de um servidor TCP rodando. O banco de dados é substituído por um arquivo temporário isolado (`tempfile`), garantindo que os testes não interfiram no ambiente de desenvolvimento.

---

## 📄 Licença

MIT © 2026
